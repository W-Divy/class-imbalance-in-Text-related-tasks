# Experiment explanation package

Start with **01_Complete_Study_Guide.html** for a readable, searchable guide with a table of contents. The Markdown copy contains the same material.

The audit covers the three supplied projects and their saved results as of 30 October 2026. Original experiment folders were read only. No expensive training or generation was rerun.

## Read in this order

1. [Complete study guide](01_Complete_Study_Guide.html) — basics, F1 worked example, every project, version differences, results, limitations and paper-writing plan.
2. [Exact evidence tables/configurations](02_Evidence_Appendix.html) — full saved tables, not selected winning rows.
3. [Source and notebook reference](03_Source_Reference.html) — complete inspected implementation with line/cell locations.
4. [Recorded changes](04_Recorded_Changes.html) — mirror diffs and EPIC launcher fix.
5. [Generation ledger](05_Generation_Ledger.html) — exact prompts and call records; large file.
6. [Additional calculations](06_Additional_Audit.html) — feature profiles, split counts and review completeness.
7. [Execution logs](07_Execution_Logs.html) — raw operational logs; large file.

## Machine-readable evidence

* [Every inventoried artifact](file_inventory.csv): 1,150 files, sizes, original paths and small-file hashes.
* [Source function/class index](source_symbol_index.csv).
* [Current/mirror comparison](mirror_comparison.csv).
* [Audit arithmetic checks](audit_checks.json).
* [Recomputed corrected-pool seed summary](correct_pool_recomputed_summary.csv).
* [Prediction-array metric checks](validation_probability_checks.csv).
* [EPIC classifier-level summaries](epic_recomputed_by_classifier.csv).
* [EPIC reconstructed confusion counts](epic_reconstructed_confusion_counts.csv).
* [EPIC generation call-by-call table](epic_generation_calls.csv).
* [EPIC feature profiles](epic_feature_profiles.csv).
* [EPIC every-candidate parser diagnostics](epic_parser_diagnostics.csv).
* [EPIC raw-response token metadata](epic_response_metadata.csv).
* [Benchmark cache audit](benchmark_cache_audit.csv).

The evidence/source/ledger appendices are reference volumes, not a recommendation to read every raw request line before understanding the study. All Markdown copies are included for reuse while writing.
