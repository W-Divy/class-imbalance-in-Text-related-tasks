# Understanding your experiments and preparing a conference paper

Evidence audit: 30 October 2026. This is an explanation and evidence guide, not a claim that a conference will accept the work. Read Sections 1–4 first, then the project sections. Equations use plain text so they remain readable offline.

## 1. What you have, and what this guide covers

You have three related research projects about using synthetic data to address class imbalance. They are separate experiments with different data, classifiers, splits, metrics and questions. Combining their numbers into one leaderboard would be invalid.

| Project | Actual question | Data type | Downstream predictor | Current evidence |
| --- | --- | --- | --- | --- |
| A: Extreme imbalance | Can local LLM augmentation help when selected text classes have very few real training examples? | Text | DistilBERT in supplied benchmark scripts | Three output stages, including 180 saved five-seed records |
| B: EPIC adaptation | How does EPIC-style tabular prompting work with a local quantized model on the released Sick split? | Mixed numerical/categorical table | Four boosting classifiers | One 1,000-row local synthetic dataset; six conditions × four classifiers × five seeds = 120 fits |
| C: Reference selection | Does choosing prompt references by classifier margin help more than randomly choosing eligible references? | Text | BERT | Three datasets, older controls, corrected controls, five training-seed pairs, and newer exploratory controls |

“Best Results” is a folder description supplied with the task. It does not establish that every method in that folder is best, that the methods are state of the art, or that the experiment is ready for submission.

This package contains:

1. **01_Complete_Study_Guide.md:** the ordered explanation, interpretation, limitations and writing plan.
2. **02_Evidence_Appendix.md:** exact saved result tables, small result JSON files, parameters and manifests, organized by source path.
3. **03_Source_Reference.md:** line-numbered Python and launcher source, plus notebook cell source. Use it to follow an implementation statement back to the code.
4. **04_Recorded_Changes.md:** exact textual differences between the current margin project and the backup, plus the EPIC launcher fix.
5. **05_Generation_Ledger.md:** saved generation prompts and call ledgers, including parsing failures. It is large; search by path, class, batch or call number.
6. **06_Additional_Audit.md:** feature distributions, generation totals, split counts, review-sheet completeness and cache diagnostics calculated during this audit.
7. CSV registers and `audit_checks.json`: machine-readable evidence and independent arithmetic checks.

The inventory contains 1,150 files across the three projects and the comparison mirror, excluding common environment/cache folders such as `__pycache__`. This audit did not retrain models, regenerate synthetic data or modify your experiment folders. Stored summaries were recomputed, and available prediction arrays were checked. It did not execute every historical environment or verify all multi-gigabyte model binaries.

There is an important limit to “every little change”: a final script cannot reveal an earlier edit that was overwritten without a version, log or backup. This guide distinguishes **saved fact**, **current code behavior**, **inference**, and **missing evidence**. The source appendix preserves implementation detail; it is not proof that the same source revision produced every historical table.

## 2. The basic problem, in ordinary language

### 2.1 A sample, feature, label, class and dataset

A **sample** is one training or evaluation example. In text classification it is a message or news text. In Sick it is one patient record. A **feature** is information the classifier receives: text tokens, age, or a categorical flag. The **label** is the answer it should predict. A **class** is one possible answer, such as joy, Sci/Tech or sick. A **dataset** is a collection of samples and their labels.

**Supervised learning** uses labeled examples to learn a mapping from inputs to labels. **Single-label classification** means each example has one target class. **Multiclass** means there are more than two possible classes. **Binary** means there are two.

### 2.2 What imbalance means

A dataset is imbalanced when some classes have many more training examples than others. The largest class is the majority; a less frequent class is a minority. There can be several minority classes. “Minority” is defined by the experimental setup, not by a universal numerical threshold.

One common imbalance ratio is `IR = largest class count / smallest class count`. Project A instead controls counts for predefined minority labels relative to a per-class majority target. The total of all non-target classes is a different denominator. A 50:1 per-class ratio does not mean that only 1/51 of a six-class dataset belongs to a given minority class.

Example: four majority classes with 400 examples each and two minority classes with 8 each give 1,616 real training examples. Each majority/minority pair has a 50:1 ratio, but all majority examples together outnumber both minorities together by 100:1.

**Artificial imbalance** is created by sampling chosen class counts, as in A. **Natural imbalance** keeps observed proportions, as in C. These ask different questions. A balanced evaluation set also represents a different target population from a naturally imbalanced evaluation set.

### 2.3 Why imbalance can hurt

An ordinary training loss sees frequent classes more often. A model can achieve a high overall accuracy by favoring them. Rare classes also offer fewer examples of their vocabulary, subtypes and unusual cases. Repeating rare rows changes training exposure; generating new rows may add useful variation, but can also add incorrect labels or unrealistic patterns.

**Augmentation** means adding training examples. **Synthetic** means produced by a process rather than directly collected as a new real observation. A repeated real row and an LLM-written sentence both increase row count, but have different information content. In A, repeated ROS rows are marked `is_synthetic=True`; that field is therefore an augmentation marker, not proof of LLM authorship.

### 2.4 The LLM is the generator, not the final classifier

The main flow is:

`real training data → choose references → prompt local Qwen → parse/filter generated samples → add training rows → train a fresh classifier → evaluate on real held-out data`.

Qwen is not directly answering every held-out classification question in these studies. DistilBERT, BERT or a boosting model performs downstream prediction. An **auxiliary scorer** in C is a separate BERT used to score real references. Its cost belongs to the augmentation method even though it is not the final predictor.

## 3. Metrics: how to calculate them and what they mean here

### 3.1 Confusion matrix and four elementary counts

For the positive class `sick`:

| Count | Meaning |
| --- | --- |
| TP: true positives | Truly sick examples predicted sick |
| FN: false negatives | Truly sick examples predicted negative |
| FP: false positives | Truly negative examples predicted sick |
| TN: true negatives | Truly negative examples predicted negative |

In a multiclass task, calculate these counts for one class against all other classes, then repeat for every class. A confusion matrix has true classes on one axis and predicted classes on the other. Check the axis labels: the matrix orientation is a display convention.

A row-normalized matrix divides each true-class row by its support. Its diagonal entries are class recalls. An entry of 0.90 means 90% of that true class received that prediction, not that 90% of the entire dataset belongs to that cell.

### 3.2 Accuracy

`accuracy = number of correct predictions / number of examples`.

On the Sick test split there are 697 negatives and 46 sick examples. A classifier predicting negative for all 743 examples would obtain `697/743 = 93.81%` accuracy while finding none of the sick examples. This is an illustrative calculation, not a fitted baseline result. It explains why accuracy alone is insufficient.

### 3.3 Precision

`precision = TP / (TP + FP)`.

Precision asks: among the examples predicted as the target class, how many actually belong to it? False positives reduce precision. It depends on the class prevalence in the evaluation population, so precision from a balanced benchmark need not transfer to a naturally rare target population.

### 3.4 Recall, sensitivity and specificity

`recall = sensitivity = TP / (TP + FN)`.

Recall asks: among the actual target-class examples, how many were found? In B, sensitivity specifically concerns the positive `sick` label.

`specificity = TN / (TN + FP)`.

Specificity asks: among actual negatives, how many were correctly rejected? These are performance measurements on the released dataset; the experiments do not establish clinical deployment suitability.

### 3.5 F1, fully worked through

`F1 = 2 × precision × recall / (precision + recall)`

Equivalently:

`F1 = 2TP / (2TP + FP + FN)`.

F1 is the harmonic mean of precision and recall. The harmonic mean penalizes a weak component more than the arithmetic mean. If precision is 1.0 and recall is 0.1, their arithmetic mean is 0.55 but F1 is about 0.182. A model cannot achieve high F1 merely by making a few extremely safe predictions and missing most of the class.

A real saved example is EPIC local augmentation, GradientBoosting, seed 0. The saved sensitivity and specificity reconstruct `TP=35, FN=11, TN=695, FP=2`. Therefore:

1. Precision = `35/(35+2) = 0.945946`.
2. Recall = `35/(35+11) = 0.760870`.
3. F1 = `70/(70+2+11) = 70/83 = 0.843373`.
4. Specificity = `695/697 = 0.997131`.
5. Accuracy, derived from these counts, = `730/743 = 0.982503`.
6. Balanced accuracy = `(0.760870+0.997131)/2 = 0.879000`.

F1 ignores TN directly. Very many easy negatives can therefore increase accuracy without improving positive-class F1. F1 also does not measure probability calibration, ranking quality or the cost of a particular error. A 0.01 change can reflect very few examples on a small minority evaluation set.

The code uses `zero_division=0`. When a required precision/recall calculation has no defined denominator, the metric uses zero according to that convention. A recorded zero minority F1 is not the same as a missing result. It indicates zero performance under the implemented scoring convention. F1 ranges from 0 to 1, often displayed after multiplication by 100. [Official F1 definition and averaging options](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html).

### 3.6 Per-class, macro, minority, majority, weighted and micro F1

**Per-class F1** calculates F1 for each label separately.

**Macro-F1** is the arithmetic mean of per-class F1: `sum(F1_c)/K`. Every class has equal weight. Do not calculate it as the F1 of averaged precision and averaged recall; those are different operations.

**Minority-F1 in A** averages only the predefined minority labels: Negative for sentiment, Love and Surprise for emotion, Sci/Tech for news. Emotion's Minority-F1 can hide one minority succeeding while the other fails. **Majority-F1 in A** averages the remaining labels. They are not weighted by class frequency.

As a consistency check, for A emotion: `Macro_F1 ≈ (2 × Minority_F1 + 4 × Majority_F1)/6`, allowing rounding. For sentiment it is `(Minority_F1 + 2 × Majority_F1)/3`; for news, `(Minority_F1 + 3 × Majority_F1)/4`.

**Weighted F1** averages per-class F1 with each class's evaluation support as its weight. It can be dominated by frequent classes. **Micro-F1** pools TP/FP/FN across classes before calculating F1; with all labels included in ordinary single-label multiclass classification, it equals accuracy. Neither should be substituted for macro-F1 without changing the claim.

**B's column named `f1` is positive-class binary F1**, because the code maps sick to 1 and uses binary `f1_score`. It is not macro-F1. **C's `macro_f1` is multiclass macro-F1** on validation. **A's `Macro_F1` is expressed on the 0–100 scale** on sampled test data. This distinction is essential when writing tables.

### 3.7 Balanced accuracy

`balanced accuracy = mean recall across classes`.

For binary B, it is `(sensitivity + specificity)/2`. For six classes, it is the mean of six recalls. It gives equal weight to each true class regardless of support, but it does not incorporate precision the way F1 does. Macro-F1 and balanced accuracy can therefore rank methods differently. [Official balanced accuracy definition](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.balanced_accuracy_score.html).

### 3.8 G-Mean and the benchmark's nonstandard floor

The usual multiclass geometric mean of recalls is:

`G = (recall_1 × ... × recall_K)^(1/K)`.

It rewards simultaneous recall across all classes. Under the unfloored definition, one zero recall makes the product zero.

A implements `100 × product(clip(recall_c, 0.0001, 1))^(1/K)`. Thus a class with zero recall contributes 0.0001 rather than zero. This is why you can see G-Mean around 3.7 despite zero sentiment minority F1. The floor is a numerical convention that changes the metric; disclose it. `baseline.py` uses a different floor, 0.001, creating another comparability difference.

### 3.9 Percentage points versus percent improvement

If macro-F1 increases from 0.70 to 0.75, the absolute gain is 0.05, or **5 percentage points** on a 0–100 display. Relative improvement is `(0.75−0.70)/0.70 ×100 = 7.14%`. Label which one you mean. Avoid relative improvement over a zero baseline; division by zero is undefined.

### 3.10 Mean, standard deviation, seeds and uncertainty

For scores `x_1...x_n`, mean is `sum(x_i)/n`. Sample standard deviation is `sqrt(sum((x_i−mean)^2)/(n−1))`. A's grouped pandas summaries use sample SD. `mean ± SD` describes observed run dispersion. It is not a 95% confidence interval and not an error bound on every future run.

A **random seed** initializes pseudorandom choices: sampling, parameter initialization, shuffling, dropout or LLM token selection. The same integer used in two pipelines does not make their data identical. GPU implementations, versions and model settings can still affect reproducibility.

In A, the seed controls training subset, sampled test subset, training and generation. Its across-seed variation mixes those sources. In C's five-seed table, synthetic texts and splits are fixed while downstream BERT training varies. In B, five classifier seeds reuse the same synthetic dataset. These are three different meanings of “multi-seed.”

A **paired difference** is `score(method1, seed s) − score(method2, seed s)`. Calculate a mean/SD over these differences, rather than subtracting two separately estimated confidence intervals. Pairing uses a shared split and seed, reducing some nuisance variability.

### 3.11 Bootstrap intervals and what the stored ones cover

A bootstrap resamples evaluation examples with replacement, recomputes the metric many times and uses the resulting distribution to estimate sampling uncertainty. **Paired bootstrap** applies the same sampled item indices to both methods. **Class-stratified bootstrap** resamples inside each true class, preserving class counts.

DAIR's `paired_bootstrap.py` uses 5,000 ordinary paired item resamples and RNG seed 2026. TREC's bootstrap uses 5,000 class-stratified resamples and RNG seed 20261010. A percentile 95% interval takes the 2.5th and 97.5th percentiles of the bootstrapped differences.

Those stored intervals condition on the chosen trained models, synthetic sets and split. They do not cover the variability of independently generating a new synthetic dataset or retraining a new scorer. A fraction of bootstrap differences above zero is not automatically a valid hypothesis-test p-value. Selection among many prompts, datasets and seeds also matters. No significance claim should be created from SD overlap alone.

## 4. Models, training and generation settings explained

### 4.1 BERT, DistilBERT and Qwen

**BERT** is a pretrained text encoder. It converts tokenized text into contextual representations; a classification head produces one logit per class. Fine-tuning adjusts the encoder and head using your labeled data. **DistilBERT** is a smaller distilled BERT-family encoder. A uses `distilbert-base-uncased`; C uses `bert-base-uncased`. These are different classifiers, so A and C are not direct numerical replications.

**Uncased** indicates case handling associated with the checkpoint/tokenizer. **Tokenization** splits text into model vocabulary units; tokens are not necessarily whole words. `input_ids` are token indices. `attention_mask` identifies real tokens versus padding. **Padding** aligns lengths within a batch or to a fixed maximum. **Truncation** cuts text beyond the configured token limit. A long news text may lose information at 128 tokens.

**Qwen2.5 3B** is the generative model used in saved local runs. “3B” refers approximately to billions of model parameters; the EPIC registry reports 3.1B. A parameter is a learned number, not a training sample. **Instruction tuning** teaches a generator to follow task instructions. A model's pretrained knowledge can include benchmark-related material; exact local overlap checks do not prove pretraining decontamination.

**Quantization** stores approximate lower-precision model weights to reduce memory and storage. EPIC records GGUF, Q4_K_M. This can affect output and is part of the method specification. The registry's model file size is not the model's total runtime memory use.

### 4.2 Logits, softmax and probability margin

A **logit** is an unnormalized class score. Softmax computes `p_c = exp(z_c)/sum_j exp(z_j)`, giving nonnegative scores summing to one. The predicted class is the highest-score class (`argmax`). These scores are often called probabilities, but confidence is not automatically calibrated.

In C, `p_true` is the score assigned to the known correct label. The strongest competing label is the **rival**, with probability `p_rival`. The margin is `p_true − p_rival`.

Example: true love=0.46, strongest rival joy=0.43 gives margin +0.03: narrowly correct. True love=0.91, rival=0.04 gives +0.87: confidently correct. True love=0.20, rival joy=0.65 gives −0.45: misclassified. The true-versus-rival margin is not the top-two predicted margin unless the true class is the top prediction.

### 4.3 Cross-entropy, class weights, focal loss and logit adjustment

Ordinary cross-entropy for one example is `−log(p_true)`. If p_true is near 1, loss is small; if near zero, loss is large. Training minimizes loss; evaluation metrics such as F1 are calculated afterward and are not directly the optimized loss here.

Class weights increase the training penalty for rare classes. C uses `w_c = N/(K × n_c)`. A v2 additionally divides all weights by their mean. For the default weighted-mean cross-entropy reduction, multiplying every class weight by the same constant cancels in the normalization; relative weights are what matter. Weights are recalculated from each condition's actual training counts, so augmentation can change both rows and effective loss weighting.

Focal loss in C is `(1−p_true)^gamma × cross_entropy`, averaged over samples, with gamma=2. Easy predictions receive less emphasis. This implementation does not add class weights to focal loss. It is a distinct baseline, not a name for weighted cross-entropy.

`baseline.py` includes training-time **logit adjustment**: it adds log class priors to logits before cross-entropy. The script predicts with unadjusted logits. That is a specific implementation choice, not a generic claim about all prior-adjustment methods. No corresponding completed output was found in A's experiment folder.

### 4.4 Epochs, batches, learning rate and optimizer steps

An **epoch** is one traversal of the training rows. A **batch** is the subset used for one update. **Learning rate** controls update size. **AdamW** adapts updates and applies decoupled weight decay; `weight_decay=0.01` is used here. **Gradient clipping** limits gradient norm; v2 and C use threshold 1.0. **Warmup** gradually increases learning rate initially; a linear schedule then reduces it. A has a 10% warmup schedule. C's basic three-epoch training uses AdamW without that scheduler.

`optimizer_steps = ceil(training_rows / batch_size) × epochs` when every partial batch is kept. C DAIR has 4,200 rows, batch 16, three epochs: 789 steps. Adding 500 rows gives 4,700 rows and 882 steps. Equal epochs therefore do not equalize training compute. Full ROS has many more rows and steps. A paper should report both added-row budget and optimizer steps.

**Mixed precision/AMP** uses lower precision for parts of training to reduce memory or speed computation, with gradient scaling to reduce underflow. A v1 uses AMP when CUDA is available. The supplied A v2 training loop does not use AMP. This is another version difference.

### 4.5 Prompt, reference, zero-shot, few-shot and attributes

A **prompt** is the generator's input. A **reference/demonstration** is a labeled example placed in it. **Zero-shot** supplies no sample demonstrations; a class name or instruction can still be present. **Few-shot** includes a small number `k` of examples. `k=5` does not mean five generated samples; it means up to five references, while the requested generated batch can contain eight or ten samples.

**Attribute prompting** varies requested style, length or tone. **Contrastive prompting** includes examples of other classes to clarify what to avoid. A **hard negative** is a non-target example close to the target in some representation. A's hard negatives use sentence-embedding proximity to a target centroid; C's references use classifier probabilities. Those are different signals.

### 4.6 Decoding and runtime vocabulary

**Temperature** rescales next-token logits before sampling; larger values generally permit more variation, without guaranteeing better diversity. **top_p** retains a probability-mass nucleus of candidate next tokens. **repeat_penalty** discourages repetition. **num_predict** limits generated tokens; it is not the number of rows. **num_ctx/context** is the context window budget for prompt plus continuation. Truncation can invalidate a supposedly equal prompt comparison.

**Ollama** serves the local generator over HTTP. `/api/chat` uses message roles; `/api/generate` sends a prompt, optionally in raw completion mode. **JSON mode** requests structured generator output but the parser must still validate it. `stream=False` requests a complete response. **Timeout** bounds how long the caller waits. **Retry** repeats a failed request; altered retry seeds/token limits should be logged. **keep_alive** controls model residency; unloading Qwen frees memory before classifier training.

**CPU**, **GPU**, **CUDA**, **VRAM** refer to processor, graphics processor, NVIDIA GPU compute support, and graphics memory. CPU offload can reduce GPU memory pressure but change runtime. Runtime includes more than model inference when there are retries, parsing and cooling pauses. Report the timed region rather than treating all minutes as directly comparable.

### 4.7 Tabular boosting models and preprocessing

GradientBoosting (`gb`), XGBoost (`xgb`), CatBoost (`cat`) and LightGBM (`lgb`) combine decision trees sequentially, with later trees addressing remaining prediction errors under their objectives. They are four model families, not four independent datasets. In this adapter the categorical inputs are ordinal encoded and all predictors receive numeric, standardized arrays; it does not use CatBoost's native categorical-feature interface.

An **ordinal encoder** maps categories to numbers. These numeric codes are identifiers; adjacent codes do not imply semantic similarity. **StandardScaler** subtracts a fitted mean and divides by a fitted standard deviation. Train-only fitting prevents held-out distribution information entering preprocessing. B fits categorical vocabularies on real training data and the scaler on each condition's training rows. This differs from fitting the scaler once for every arm.

**Cross-validation (CV)** splits training data into folds, trains on some and scores on the remaining fold, repeating across folds. **Stratified five-fold CV** approximately preserves class proportions. **Grid search** tries combinations of parameter values. This selects hyperparameters from training data and is different from reporting final test performance. A saved selected-parameter file alone does not retain the CV score history or prove when it was produced.

## 5. Project A: extreme-imbalance benchmark, step by step

### 5.1 Locate the three stages before using a table

Root: `D:\EXPERIMENTS`.

| Stage | Saved output | What is actually present | Supplied implementation |
| --- | --- | --- | --- |
| A1 | `results_conference` | Five RQ CSVs, 58 generation caches, seven figure pairs, LaTeX tables and log | `run_imbalance_ollama.py` |
| A2 | `results_conference_v2` | 72 metric records: 3 tasks × 4 ratios × 3 methods × 2 seeds; 32 caches; log | `run_imbalance_v2.py` |
| A3 | `result_conference_v2_new` | 180 records: same grid with five seeds; one summary CSV | No run-specific source snapshot, log, generation caches or config in this folder |

A3 seeds are 42, 123, 2024, 77 and 999. A2 seeds are 42 and 123. A1 saved rows use seed 42 and Qwen only. Source code listing four available generators does not establish that four were evaluated. A1 CSV row counts are RQ1=18, RQ2=48, RQ3=12, RQ4=12 and RQ5=21. Some rows repeat the same comparisons across RQs, so 111 table rows are not 111 independent experiment designs.

A1's log runs from 25 October 2026 15:28 to 17:40 in its recorded local timestamps. A2's log runs approximately 17:57–18:53 on that date. These are log spans, not independently measured GPU-only durations. A3 lacks an execution log in the named folder. Filesystem modification times in the inventory are not substitutes for a run log, especially after copying files.

### 5.2 Datasets, labels and sampling

| Task key | Dataset identifier | Class labels | Designated minorities | Default majority count per other class | Requested test cap per class |
| --- | --- | --- | --- | --- | --- |
| sentiment | `cardiffnlp/tweet_eval`, sentiment config | 0 Negative, 1 Neutral, 2 Positive | 0 | 500 | 200 |
| emotion | `dair-ai/emotion` | 0 Sadness, 1 Joy, 2 Love, 3 Anger, 4 Fear, 5 Surprise | 2 and 5 | 400 | 150 |
| ag_news | `fancyzhx/ag_news` | 0 World Politics, 1 Sports, 2 Business & Finance, 3 Sci/Tech | 3 | 500 | 200 |

The label strings in the prompt are the script's descriptions. In particular “World Politics” is the chosen description of AG News label 0; do not assume it is an exact, complete restatement of the upstream World category.

Each seed samples real training rows within each class. Minority count is `max(4, floor(N_majority/IR))`. Test rows are separately sampled from the upstream test split, using `min(available_rows, test_cap)`. Therefore “150 per emotion test class” is a cap, not a guaranteed count. Do not automatically report exactly 900 emotion test examples. The known small Surprise split and the saved accuracy increments are consistent with a smaller total; a run manifest with explicit sampled row IDs/counts is still needed for A3.

Default full-size training counts implied by the current configuration:

| IR | Sentiment minority / total | News minority / total | Emotion each minority / total |
| --- | --- | --- | --- |
| 50 | 10 / 1,010 | 10 / 1,510 | 8 / 1,616 |
| 25 | 20 / 1,020 | 20 / 1,520 | 16 / 1,632 |
| 10 | 50 / 1,050 | 50 / 1,550 | 40 / 1,680 |
| 5 | 100 / 1,100 | 100 / 1,600 | 80 / 1,760 |

These are **code-derived full-configuration counts**, not verified A3 run manifests. A1 `--fast_dev` sets majority counts to 150 for every task and test caps to 80. A2 `--fast_dev` sets majority counts to 150 but retains the default test caps and forces seeds 42/123. A2 cache sizes of 146, 144, 135 and 120 for single-minority tasks, and 71, 69, 60 and 45 per emotion minority, agree with that reduced-count configuration. This supports an inference that A2 used the fast profile, but there is no saved command line proving every option.

The minimum of four rows means nominal IR and achieved IR can differ. With majority=150 and nominal IR=50, `floor(150/50)=3`, which is increased to four, making achieved ratio 37.5:1. With IR=25, the minority is six and achieved ratio is 25:1. Always record achieved counts beside the requested IR.

### 5.3 A1 baselines

**No augmentation:** use the imbalanced real rows and fine-tune DistilBERT with ordinary loss. It tests how the classifier behaves without extra examples.

**Random oversampling (ROS):** sample existing minority rows with replacement until each designated minority reaches the per-class majority target. It changes exposure without adding new semantic content.

**EDA heuristic:** fill the minority gap with simple text perturbations. The implementation chooses a swap of two words, random deletion with probability 0.15 per word, or insertion of a word copied from the sentence. Text shorter than four words is returned unchanged. This is a small heuristic implementation; calling it the complete published EDA algorithm would overstate it. It has no synonym-replacement stage. Perturbations can damage grammar or change meaning, and the code does not independently verify labels.

All A1 final classifiers default to four epochs, batch 32, learning rate 3e-5, weight decay 0.01, maximum 128 tokens, evaluation batch 64 and 10% warmup. Source CLI `--epochs` can override four. Saved A1 output alone does not retain a complete execution config, so these are supplied defaults rather than an independently verified command line.

### 5.4 A1 prompt conditions

| Code method | What is added to the prompt or generation procedure |
| --- | --- |
| `zero_shot` | Class descriptions/instructions, no minority references |
| `few_shot_minority` | Up to k real target-class examples |
| `attr_prompt` | Minority references plus rotating length, tone and vocabulary instructions |
| `random_majority` | Minority references plus up to four random non-target examples |
| `contrastive_majority` | Minority references plus up to four embedding-selected non-target examples |
| `cot_boundary_filtered` | Contrastive examples, attributes, a request to silently contrast labels, 1.35× candidate pool and geometric ranking |

The `cot` method name is not evidence that internal chain-of-thought was observed or that reasoning quality was measured. The prompt requests silent contrast and saves final text. A1's acronym `CBAP` appears in a result label; it should be defined explicitly in a paper if retained. The saved label is not itself a standard published method identity.

A1 attributes rotate over five triples: concise/formal/explicit; moderately detailed/conversational/subtle; expressive/narrative/contrastive; short/matter-of-fact/colloquial; nuanced/reflective/implicit. A2 reduces this to the first three and uses a simpler prompt.

### 5.5 Hard-negative retrieval and geometric filtering

SentenceTransformer `all-MiniLM-L6-v2`, on CPU, embeds text into normalized vectors. A **sentence embedding** represents the sentence numerically. For normalized vectors, dot product equals cosine similarity. A **centroid** is the mean of a class's embeddings; because an average of unit vectors need not have length one, dot products with that mean are not automatically cosine similarities to a renormalized centroid.

A1 hard-negative retrieval takes the target minority centroid and ranks every non-target training example by its dot product with that centroid, keeping four. It is centroid proximity, not a learned DistilBERT decision-boundary distance. When emotion has two minority classes, the other minority is included among the non-target examples; “majority” in this function means all non-target labels rather than only the designated majority classes.

For a synthetic candidate vector `e`, the geometric filter computes:

`score(e) = e·target_centroid − 0.85 × max_j(e·other_class_centroid_j)`.

It ranks candidates from highest to lowest and keeps the requested count. This favors closeness to the target centroid relative to other-class centroids. It does not certify semantic label correctness. It has a fixed coefficient 0.85 with no saved sensitivity sweep.

If candidates do not exceed the target count, the filter returns them without ranking. Thus the filter's effective action depends on generating an excess pool. Different prompt content, candidate budget and filtering are bundled in `cot_boundary_filtered`; a performance difference cannot isolate one of those components without more ablations.

### 5.6 Generation, parsing, duplicate checks and fallback

A1 requests eight texts per call at temperature 0.85, top_p=0.92, repeat_penalty=1.12, output limit 320 tokens and seed=`seed+attempt`. It strips numbering, bullets, quotes and `SAMPLE:` prefixes; accepts strings 15–500 characters long; and rejects a few common introductory phrases. It rejects exact duplicate strings within the collection and exact matches to the target-class reference pool.

This is syntax/length filtering, not label verification. It does not normalize case/whitespace before its duplicate comparison and does not check against every held-out text. My audit found zero exact-string duplicate excess in the saved caches but eight normalized duplicate excess rows across A1 caches and three across A2 caches. These totals sum within-cache excesses, not duplicates across all caches combined. They demonstrate the difference between exact and normalized matching.

If A1 generation falls short, the code adds EDA transformations of real target examples. If A2 falls short, it adds a real target example followed by ` [augmented]`. Such a row is not newly generated by Qwen. The saved A2 caches contain no `[augmented]` markers, which rules out that specific marker in those files but does not validate A3, whose caches are absent. A1's EDA fallback is not tagged separately, so its prevalence cannot be fully reconstructed from final strings alone.

The cache filename records generator key, task, label, prompt method, k, number requested and seed. It omits source-data hashes, code hash, decoder settings and actual model digest. Changing those while reusing a cache can silently reuse stale synthetic data. A2 additionally returns an existing cache slice without checking that enough rows exist; A1 checks the cache has sufficient length first.

### 5.7 What each A1 research question really tests

**RQ1 — reference count:** k values are 0,1,3,5,10,15 at nominal IR=25. k=0 uses zero-shot; positive k uses contrastive-majority prompting. Therefore the zero-to-positive contrast changes both demonstration count and majority-context inclusion. The available real target pool can contain fewer examples than k, so requested k need not equal actual k. Under majority=150/IR=25 there are only six target examples; k=10 or 15 still samples only six. Do not claim a true 15-example demonstration treatment from the name alone.

Observed minority-F1 optima are sentiment k=5 (35.66), emotion k=15 (25.44), news k=15 (46.73). These are one-seed observations; they do not establish a universal best k, and the effective-k limitation applies.

**RQ2 — imbalance ratio:** compares no augmentation, ROS, heuristic EDA and Qwen+CBAP for IR=50,25,10,5. The minority training amount changes with ratio, and the augmentation amount changes too. This is a controlled severity study, not a same-data comparison between ratios. A1 baselines often collapse on designated minorities. That makes loss-strength controls especially important before presenting large synthetic-data gains.

**RQ3 — non-target context:** compares minority-only, random non-target references, hard negatives, and contrastive+filter. Hard negatives help some rows and hurt others. For news, minority-only Minority-F1 is 46.73, versus 34.69 for hard-negative context and 39.60 for filtered contrastive prompting. For emotion, random non-target context reaches 29.74, above the filtered method's 24.71. The evidence does not support “hard negatives always help.”

**RQ4 — embedding distributions:** measures target-class fidelity and geometry, using only the first designated minority label for emotion (Love). It is not an analysis of both emotion minorities. Its real target reference distribution concatenates selected training **and test** examples. This is a post-hoc test-informed diagnostic. It is not proof of training leakage in the classifier, because the filter itself uses training centroids; however, using these diagnostics to tune methods would compromise the independence of the test evaluation.

**RQ5 — prompt methods:** compares the five prompts and two real-data baselines at IR=25. Saved results evaluate Qwen only. Attribute prompting has the highest news macro-F1 among listed Qwen prompts, 77.70; filtered contrastive prompting has the highest sentiment macro-F1, 52.38; minority-only prompting has the highest emotion macro-F1 among those five Qwen prompts, 46.98. There is no single prompt winner across tasks.

### 5.8 Embedding metrics and t-SNE explained

**Fréchet embedding distance (FED)** compares two distributions by their embedding means and covariance matrices:

`FED = ||mu_real−mu_syn||² + Tr(Sigma_real + Sigma_syn − 2 sqrt(Sigma_real Sigma_syn))`.

Mean summarizes location, covariance summarizes spread and relationships between embedding dimensions, trace sums diagonal terms, and the matrix square root is not an elementwise square root. A1 adds 1e-5 to covariance diagonals, removes the imaginary part of the numerical square-root result if present, and clips the final distance below at zero. Lower is interpreted as closer under this approximation. With very few real minority examples and many embedding dimensions, covariance estimation is fragile. FED is neither F1 nor a calibrated test of correct generated labels.

**Cosine diversity** is `1 − mean pairwise cosine similarity` among synthetic embeddings, using upper-triangle pairs and excluding self-similarity. Larger values mean more dispersed embeddings. A wrong-class sentence can increase diversity; more diversity is not automatically more useful training data.

**Reported Boundary_Margin in RQ4** is the average synthetic dot product with the combined real target centroid minus its dot product with the pooled non-target training centroid. It differs from the filter score: no 0.85 factor, pooled non-target centroid instead of strongest competing centroid, and target test examples included. It also differs from C's probability margin.

**t-SNE** reduces embeddings to two coordinates for visualization. The code uses perplexity 30, PCA initialization, automatic learning rate and random_state=42, embedding both synthetic conditions together before displaying them. It takes up to 240 non-target real rows, 120 target test rows and 120 synthetic rows from each condition. Distances between far-apart clusters and empty spaces are not reliable direct distances in the original embedding space. A plot cannot prove label purity, mode collapse or a causal boundary mechanism.

### 5.9 A2: what the supplied v2 changes

Compared with A1, v2 narrows the benchmark to three conditions: no augmentation, ROS and attribute-prompted Qwen. It removes EDA, hard-negative prompting, geometric filtering and the five RQ presentation pipeline. It applies class-weighted cross-entropy to every condition, defaults to three rather than four epochs, adds gradient clipping, omits AMP, simplifies generation, and defaults to five seeds. Its completed saved A2 output uses two seeds.

The header says class weighting prevents collapse, but this is an intention, not a guarantee: saved A2 minorities still sometimes have zero F1. A2 calls the no-added-rows method “No Augmentation” while using weights in current source. Label a reproducible arm “class-weighted, real-only DistilBERT” when that source is confirmed. Do not imply it is an ordinary unweighted baseline solely because of the row name.

**Emotion budget defect:** v2 computes one total shortfall `needed = majority_target − total_count_of_all_minority_rows`, then divides that shortfall between the two minorities. With majority target M and each original minority count m, each receives approximately `(M−2m)/2`, ending near M/2. ROS independently fills each minority to M. For full-size M=400, LLM ends near 200 per minority whereas ROS ends at 400. For reduced M=150, LLM ends near 75. For sentiment/news with one minority, the formula is correct for full balancing. This is a code-confirmed problem in the supplied v2; its application to A3 remains unverified without that run's source snapshot.

This difference matters in two ways: it changes minority exposure and total optimizer steps, and the resulting class weights are also different. It prevents a clean equal-budget attribution of emotion differences to synthetic quality alone.

### 5.10 A3: the complete five-seed result pattern

The following tables are recomputed from A3's 180 saved rows. Values are mean ± sample SD on the original percentage scale. These are observed results; the execution provenance gap discussed above remains.

#### ag_news

| IR | Method | Macro_F1 | Minority_F1 | G_Mean |
| --- | --- | --- | --- | --- |
| 5 | LLM (AttrPrompt) | 86.690 ± 1.170 | 79.022 ± 3.257 | 86.094 ± 1.376 |
| 5 | No Augmentation | 88.046 ± 1.125 | 83.300 ± 2.525 | 87.710 ± 1.202 |
| 5 | Random Oversampling | 87.238 ± 0.731 | 80.682 ± 2.085 | 86.700 ± 0.824 |
| 10 | LLM (AttrPrompt) | 83.708 ± 1.705 | 70.890 ± 4.422 | 82.426 ± 1.972 |
| 10 | No Augmentation | 85.762 ± 1.189 | 77.408 ± 2.683 | 85.046 ± 1.268 |
| 10 | Random Oversampling | 83.398 ± 1.640 | 70.062 ± 3.964 | 81.974 ± 1.954 |
| 25 | LLM (AttrPrompt) | 77.524 ± 1.654 | 52.850 ± 6.060 | 73.954 ± 2.696 |
| 25 | No Augmentation | 74.554 ± 5.060 | 43.212 ± 16.052 | 68.338 ± 10.166 |
| 25 | Random Oversampling | 74.658 ± 1.076 | 43.348 ± 2.512 | 69.390 ± 1.298 |
| 50 | LLM (AttrPrompt) | 73.634 ± 1.340 | 40.244 ± 4.932 | 67.694 ± 2.493 |
| 50 | No Augmentation | 64.228 ± 2.376 | 8.500 ± 8.231 | 33.802 ± 22.283 |
| 50 | Random Oversampling | 67.410 ± 2.721 | 19.666 ± 9.143 | 54.166 ± 6.593 |


#### emotion

| IR | Method | Macro_F1 | Minority_F1 | G_Mean |
| --- | --- | --- | --- | --- |
| 5 | LLM (AttrPrompt) | 72.438 ± 2.609 | 63.414 ± 3.927 | 70.826 ± 2.840 |
| 5 | No Augmentation | 73.146 ± 2.113 | 68.894 ± 2.137 | 72.908 ± 2.234 |
| 5 | Random Oversampling | 79.808 ± 1.813 | 75.630 ± 2.713 | 79.640 ± 1.954 |
| 10 | LLM (AttrPrompt) | 63.610 ± 2.659 | 41.536 ± 6.447 | 56.760 ± 4.215 |
| 10 | No Augmentation | 62.014 ± 5.895 | 42.634 ± 14.214 | 48.456 ± 20.485 |
| 10 | Random Oversampling | 74.254 ± 2.183 | 62.522 ± 5.032 | 71.334 ± 2.699 |
| 25 | LLM (AttrPrompt) | 52.436 ± 2.018 | 10.678 ± 4.877 | 31.770 ± 5.183 |
| 25 | No Augmentation | 46.802 ± 1.273 | 0.298 ± 0.666 | 5.114 ± 2.358 |
| 25 | Random Oversampling | 61.200 ± 2.869 | 28.368 ± 6.915 | 47.788 ± 6.010 |
| 50 | LLM (AttrPrompt) | 49.960 ± 2.137 | 2.796 ± 3.080 | 12.876 ± 10.240 |
| 50 | No Augmentation | 47.950 ± 1.146 | 0.000 ± 0.000 | 4.126 ± 0.063 |
| 50 | Random Oversampling | 52.292 ± 1.460 | 4.798 ± 4.225 | 19.730 ± 11.883 |


#### sentiment

| IR | Method | Macro_F1 | Minority_F1 | G_Mean |
| --- | --- | --- | --- | --- |
| 5 | LLM (AttrPrompt) | 63.358 ± 0.827 | 65.766 ± 3.139 | 62.686 ± 0.742 |
| 5 | No Augmentation | 64.850 ± 2.416 | 70.406 ± 3.216 | 64.016 ± 2.846 |
| 5 | Random Oversampling | 64.998 ± 2.200 | 65.958 ± 3.836 | 64.358 ± 2.452 |
| 10 | LLM (AttrPrompt) | 60.504 ± 2.391 | 57.146 ± 5.211 | 59.710 ± 2.644 |
| 10 | No Augmentation | 60.308 ± 2.818 | 57.306 ± 10.903 | 58.920 ± 4.237 |
| 10 | Random Oversampling | 59.030 ± 2.916 | 50.020 ± 5.166 | 57.058 ± 3.604 |
| 25 | LLM (AttrPrompt) | 56.926 ± 1.950 | 48.404 ± 2.952 | 55.468 ± 2.174 |
| 25 | No Augmentation | 39.560 ± 0.819 | 0.000 ± 0.000 | 3.732 ± 0.072 |
| 25 | Random Oversampling | 49.354 ± 4.190 | 23.796 ± 12.816 | 41.224 ± 8.739 |
| 50 | LLM (AttrPrompt) | 54.534 ± 3.084 | 42.134 ± 7.949 | 52.252 ± 4.274 |
| 50 | No Augmentation | 39.862 ± 0.447 | 0.000 ± 0.000 | 3.784 ± 0.037 |
| 50 | Random Oversampling | 43.162 ± 3.134 | 7.576 ± 8.051 | 24.642 ± 11.304 |


Interpretation in full:

* **Sentiment IR=50:** LLM macro-F1 54.534 versus ROS 43.162 and real-only 39.862. LLM improves minority-F1 from zero to 42.134 on average. This is the clearest saved severe-sentiment pattern.
* **Sentiment IR=25:** LLM macro-F1 56.926 versus ROS 49.354 and real-only 39.560. Minority-F1 is 48.404 versus ROS 23.796. This supports a conditional gain in this setup.
* **Sentiment IR=10:** all macro means are closer: LLM 60.504, real-only 60.308, ROS 59.030. A 0.196-point LLM–real-only difference is too small to call a robust gain from means alone.
* **Sentiment IR=5:** ROS and real-only macro-F1 are about 65, while LLM is 63.358; real-only has the highest minority-F1, 70.406. The severe-regime benefit does not persist uniformly as real minority data increases.
* **News IR=50:** LLM macro-F1 73.634 versus ROS 67.410 and real-only 64.228. Minority-F1 is 40.244 versus ROS 19.666 and real-only 8.500.
* **News IR=25:** LLM macro-F1 77.524 versus ROS 74.658 and real-only 74.554. Its advantage is smaller than at IR=50.
* **News IR=10:** real-only macro-F1 85.762 exceeds LLM 83.708 and ROS 83.398. Added synthetic data is not automatically beneficial when more real minority examples exist.
* **News IR=5:** real-only 88.046 exceeds ROS 87.238 and LLM 86.690.
* **Emotion IR=50:** ROS 52.292 exceeds LLM 49.960 and real-only 47.950. Minority-F1 remains low for both augmentation approaches.
* **Emotion IR=25:** ROS 61.200 exceeds LLM 52.436 and real-only 46.802. ROS minority-F1 28.368 exceeds LLM 10.678.
* **Emotion IR=10:** ROS 74.254 exceeds LLM 63.610 and real-only 62.014. LLM minority-F1 41.536 is slightly below real-only 42.634.
* **Emotion IR=5:** ROS 79.808 exceeds real-only 73.146 and LLM 72.438. The possible budget defect prevents attributing this to generation quality alone.

These observations suggest an interaction among task, severity and augmentation. They do not establish an all-task improvement or an overall winning method. Report all ratios, including the regimes where LLM augmentation loses. A3 contains the strongest available multi-seed table by run count, but not the strongest provenance.

### 5.11 The separate `baseline.py` is not a completed matched control

It defaults to RoBERTa, 20 real minority examples, ratios 25/50, seeds 42/123/2024, three epochs, batch 32 and learning rate 2e-5. It uses only Surprise as emotion minority and Business label 2 as AG News minority. Main A scripts use Love+Surprise and news Sci/Tech label 3. Its test cap, input lengths, loss variants, G-Mean floor and output path `/content/quick_baselines.csv` also differ. It uses nested majority subsets while holding 20 minority examples fixed, unlike A's main severity construction.

Its ROS target is the current average per-class count rather than the largest class count, despite an approximate-balancing comment. You must reconcile all these choices before combining its numbers with A3. No completed `quick_baselines.csv` was present in the supplied A folder.

### 5.12 Existing plots and LaTeX tables need careful labeling

The seven PNG/PDF figure pairs and `paper_tables.tex` were made from A1, not from the A3 five-seed results. Copying them into a paper beside A3 tables would mix experiment stages unless explicitly separated.

I inspected the saved RQ2 plot, emotion t-SNE plot and RQ5 heatmap. RQ2's plotting code groups by method and ratio **without a task facet**, so the line averages across datasets; its shaded region is not five-seed uncertainty. RQ5 averages macro-F1 across tasks and only shows Qwen as an actual generator; its architecture-comparison title overstates the saved coverage. The t-SNE subtitles assert mode collapse versus clear margins in advance; replace them with neutral condition labels unless separately established.

The LaTeX file contains generated tables, captions, labels and `booktabs` commands. It formats A1 observations; it does not add statistical validation. RQ3/RQ4 merging attaches a first-seed diagnostic to aggregated prediction metrics, which would need explanation in a multi-seed extension.

### 5.13 What A can currently support

Paper-safe statement: “In the saved five-seed benchmark, attribute-prompted local LLM augmentation improves macro-F1 over the listed controls on sentiment and news at nominal ratios 25 and 50, while the ranking changes at lower ratios and on emotion.” Add the provenance and emotion-budget limitations.

Before submission: recover the exact A3 run script/command/config, save sampled splits and hashes, verify weighting and epochs, preserve actual generation/model identity, fix/equalize emotion budgets in a new version, add matched strong loss controls, and rerun on a protocol with a separate development set. A3's CSV summary arithmetic is correct; that alone cannot settle these design questions.

## 6. Project B: EPIC local tabular adaptation

### 6.1 Aim and original attribution

Root: `D:\EPIC_free_reproduction\epic-free`.

EPIC stands for **Effective Prompting for Imbalanced-Class Data Synthesis in Tabular Data Classification via Large Language Models**, by Jinhee Kim, Taesung Kim and Jaegul Choo, NeurIPS 2024. It studies balanced/grouped demonstrations and category mapping for tabular synthesis. Your local adapter substitutes Qwen and implements the prompting mechanism on Sick; EPIC is an existing method, not a new invention of this project. [Original EPIC proceedings entry](https://proceedings.neurips.cc/paper_files/paper/2024/hash/37f2f382b1e1f1e887d610e7ea047086-Abstract-Conference.html), [official repository](https://github.com/seharanul17/synthetic-tabular-LLM).

The local README and `VALIDATION.md` describe an earlier delivery state. They say a local 1,000-row generation and complete classifier runs were not executed. The current artifacts supersede those statements for this local run: there is a completed generation, six conditions and 120 fits. The exact run configs and outputs are stronger evidence of completion than the stale prose. They do not imply the optional neural baselines or all published datasets were completed.

### 6.2 The exact dataset and positive label

`data/Sick` contains `X_train.csv`, `y_train.csv`, `X_test.csv` and `y_test.csv`. X files hold features and y files hold Class. The `index` column aligns each X row with its y label; the loader asserts matching indices, then drops that index from the modeling table. It prepends Class for prompting.

| Split | Negative | Sick | Total |
| --- | --- | --- | --- |
| Real training | 2,783 | 185 | 2,968 |
| Real test | 697 | 46 | 743 |

The training majority/minority ratio is `2783/185 = 15.043:1`. The positive share is 6.233% of training and 6.191% of test. There are 27 predictors: six numerical and 21 categorical. Including Class, the generator must output exactly 28 columns. Saved audit reports no full-row duplicates inside either real split and no identical full rows across the two. This is not a guarantee that distinct rows do not describe related individuals; no subject-group analysis is recorded.

The audit stores SHA-256 hashes of all four CSVs. A **hash** is a content fingerprint; it identifies exact bytes. Matching hashes establish identical files with extremely high practical confidence, not correctness of labels or experimental design.

### 6.3 Every feature, and what can safely be said about it

The descriptions below explain the fields at the dataset level. The local package contains preprocessed values; it does not include a full raw-to-preprocessed derivation or a unit dictionary. Do not invent medical units, imputation rules or clinical interpretations from the names alone. In particular the feature `sick` is a predictor flag and is distinct from target `Class='sick'`.

| Field | Type in adapter | Plain-language meaning / interpretation limit |
| --- | --- | --- |
| age | numerical | Recorded age; the real training maximum is 455, so raw data quality cannot be assumed from the name |
| sex | categorical | Recorded sex category; `?` is retained as a category when present |
| on_thyroxine | categorical | Flag indicating thyroxine treatment |
| query_on_thyroxine | categorical | Query/uncertainty flag related to thyroxine treatment |
| on_antithyroid_medication | categorical | Flag for antithyroid medication |
| sick | categorical | Predictor flag named sick; not the Class target |
| pregnant | categorical | Recorded pregnancy flag |
| thyroid_surgery | categorical | Recorded thyroid-surgery flag |
| I131_treatment | categorical | Recorded iodine-131 treatment flag |
| query_hypothyroid | categorical | Query flag related to hypothyroidism |
| query_hyperthyroid | categorical | Query flag related to hyperthyroidism |
| lithium | categorical | Recorded lithium-related flag |
| goitre | categorical | Recorded goitre flag |
| tumor | categorical | Recorded tumor flag |
| hypopituitary | categorical | Recorded hypopituitary flag |
| psych | categorical | Source flag named psych; exact coding definition requires the upstream dictionary |
| TSH_measured | categorical | Whether the TSH measurement is recorded as measured |
| TSH | numerical | Thyroid stimulating hormone field |
| T3_measured | categorical | Measurement-status flag for T3 |
| T3 | numerical | Triiodothyronine field |
| TT4_measured | categorical | Measurement-status flag for TT4 |
| TT4 | numerical | Total thyroxine field |
| T4U_measured | categorical | Measurement-status flag for T4U |
| T4U | numerical | Thyroxine uptake field |
| FTI_measured | categorical | Measurement-status flag for FTI |
| FTI | numerical | Free thyroxine index field |
| referral_source | categorical | Recorded source category, e.g. other, SVI, SVHC, STMW, SVHD; expansions not specified locally |

Categorical flags are usually stored as `t`/`f`; the exact domains and counts for every field are in `epic_feature_profiles.csv`. `keep_default_na=False` preserves strings such as `?` rather than converting them into missing values. The loader does not newly impute numerical values. Values like 2.013504330446369 in T3 are present in the preprocessed table; they are not evidence of a raw measured precision at that many digits.

### 6.4 Category mapping: why and how it works

The adapter replaces every categorical value, including Class, with a globally unique three-character code. It uses a seeded Python RNG: the first character is uppercase A–Z and the next two are uppercase letters or digits. A shared `used` set prevents a code being assigned to two values across any columns. Values are visited in sorted order inside each categorical column. The mapping is saved in `mapping.json` and reversed after generation.

This makes category spelling consistent in the prompt and makes invalid categories detectable. It does not make codes semantically meaningful or remove the need to model category relationships. Coding maps and ordinal-encoder maps serve different purposes: the first formats the LLM prompt, the second supplies numeric classifier inputs.

### 6.5 The complete prompt construction

The completed run uses four sets, three examples per class per set and two classes: `4 × 3 × 2 = 24` distinct demonstrations in one prompt. It samples 12 distinct rows from each class across all four sets. Row repetition is disallowed within a prompt, but rows can reappear in later calls.

The prompt begins with concise descriptions of Class and selected variables. Each set has a 28-column CSV header, then A and B class groups and their rows. The same class order is used consistently. After four sets it ends with another CSV header to invite continuation. There is no model fine-tuning in this generation stage.

The supplied notes describe the original released Sick profile as four sets of 15 examples per class, totaling 120 demonstrations. Your completed run uses 24; this is a substantial context/sample change, not a minor formatting detail. The optional 120-demo command is present but not a completed output in the provided run folders.

### 6.6 Actual model and generation configuration

Saved `runs/local-epic/config.json` records:

| Parameter | Value | Consequence |
| --- | --- | --- |
| model | qwen2.5:3b | Local generator substitution |
| variant | epic | Mapped, balanced and grouped CSV demonstrations |
| requested final rows | 1,000 | Exact final generation target |
| sets / per_class | 4 / 3 | 24 demonstrations per prompt |
| context | 8,192 tokens | Configured input-plus-output context budget |
| output tokens | 1,024 | Maximum continuation per call |
| temperature | 0.7 | Sampling setting |
| seed | 0 | Base mapping/sampling/generation seed |
| max_calls | 1,000 | Hard stop if target cannot be reached |
| raw / streaming | true / false in source | Raw completion, one complete response per request |
| request num_batch | 128 in source | Inference processing setting, not row batch count |

`ollama_models.json` records GGUF format, qwen2 family, 3.1B parameters, Q4_K_M quantization, model size 1,929,912,432 bytes and digest `357c53fb659c5076de1d65ccb0b397446227b71a42be9d1603d46168015c9e4b`. The registry context capability is 32,768, while the actual run requests 8,192. Record both correctly rather than substituting capability for execution configuration.

### 6.7 Parsing and acceptance: all the important details

The parser examines comma-containing candidate lines, skips the exact header, uses CSV parsing, requires exactly 28 values, strips surrounding whitespace, converts the six numerical fields to finite floats and validates every category against the real training domain after reversing the mapping. Unknown codes, wrong widths, malformed sentence formatting, nonnumeric values and NaN/infinite values are rejected.

Finite does not mean realistic. The parser performs no age range, measurement consistency or physiological plausibility checks. It does not remove duplicates or exact training matches. Those are audited separately. It also cannot verify whether the generated Class is substantively correct from features.

After each call, the raw response is saved, the call ledger is flushed and all valid rows are written to `synthetic_all.csv`. If the prompt's measured input-token count plus requested output budget approaches the context limit within 64 tokens, the adapter raises an error rather than knowingly accepting a likely truncated prompt. At max calls without enough rows it raises an error and retains partial output.

Once at least 1,000 rows are accepted, it randomly selects exactly 1,000 using the fixed run seed and writes `synthetic.csv`. It does not simply truncate the last group, which could bias class balance. It does not force the accepted outputs into equal class counts.

### 6.8 What actually happened in generation

| Quantity | Saved/recomputed value |
| --- | --- |
| Calls made | 166, numbered 0–165 |
| Calls accepting no valid rows | 11 |
| Candidate CSV-like lines | 2,195 |
| Accepted rows before final selection | 1,007 = 562 negative + 445 sick |
| Rejected candidate lines | 1,188 |
| Valid fraction | 0.458770, or 45.877% |
| Summed request time | 2,812.847 seconds = 46.881 minutes |
| Accepted rows per timed second | 0.358000 |
| Total prompt tokens | 476,646 |
| Total continuation tokens | 168,905 |
| Total tokens / accepted row | 641.064 |
| Final selected rows | 1,000 = 557 negative + 443 sick |
| Duplicate excess in final set | 1 row |
| Final rows matching real train exactly under audit key | 4 rows |

“Candidate line” means a line considered CSV-like by the parser, not every line of model prose. Timing sums the measured HTTP requests, not setup, prompt construction or downstream fitting. Token counts include repeated demonstrations on each request. Tokens per valid row uses 1,007 accepted rows, not the selected final 1,000.

The final pool is much more balanced than real training, yet its sick share is 44.3%, not 50%. A successful 1,000-row run is evidence of pipeline completion, not evidence that those rows are high-quality or improve classification.


A reconstruction of every saved local EPIC candidate-line parse gives the following first-failure reasons. A line can have multiple defects; this follows parser order and records the first.

| Outcome | Candidate lines |
| --- | --- |
| accepted | 1007 |
| wrong_column_count | 1130 |
| unknown_category_code | 58 |

The corresponding candidate text and response line are preserved in `epic_parser_diagnostics.csv`; response timing/token/done metadata is in `epic_response_metadata.csv`. These diagnostics were reconstructed from saved responses, not observed as separately logged reason labels in the original parser.

### 6.9 Six evaluated training conditions

| Condition | Training composition | Training rows | Added real/synthetic budget |
| --- | --- | --- | --- |
| original | Real training only | 2,968 | 0 |
| augment | Real + all final local synthetic rows | 3,968 | 557 negative + 443 sick |
| minority | Real + generated sick rows only | 3,411 | 443 sick |
| synthetic | Generated rows only | 1,000 | No real rows used for fitting predictor |
| smote | Resampled real training | 5,566 | 2,598 generated minority feature vectors |
| smotenc | Resampled real training with categorical handling | 5,566 | 2,598 generated minority feature vectors |

Minority-only augmentation increases sick from 185 to 628 while negative stays 2,783: it does not fully balance the training table. Full augmentation has 3,340 negatives and 628 sick, ratio about 5.318:1. SMOTE variants balance to 2,783 per class. These are unequal budgets, so a performance comparison is not a pure comparison of generator quality at fixed row count.

**SMOTE** creates numerical feature vectors by interpolating minority neighbors: conceptually `x_new = x_i + lambda(x_neighbor−x_i)` for lambda between 0 and 1. Ordinary SMOTE on ordinal category codes can create fractional categories that do not represent real category values. This implementation is retained as a named numerical baseline, not validated tabular semantics.

**SMOTENC** treats designated categorical columns categorically while interpolating continuous components. That is a more appropriate schema treatment for mixed data, but does not guarantee better downstream scores or realistic relationships. [Official SMOTENC documentation](https://imbalanced-learn.org/stable/references/generated/imblearn.over_sampling.SMOTENC.html).

All six conditions predict the same 743 real test rows. Synthetic-only still uses the real-training-fitted category vocabulary; “synthetic-only” refers to fitting classifier/scaler on synthetic rows, not to never consulting the real training schema.

### 6.10 Four classifiers, tuning and seed handling

Each condition runs `gb,xgb,cat,lgb` for seeds 0–4. That is 20 fits per condition, 120 total. Five classifier fits reuse one generated dataset; they are not five independent Qwen generations.

Saved `classifier_params.json` selects learning_rate/max_depth: XGBoost 0.1/6, CatBoost 0.03/6 and LightGBM 0.1/6. GradientBoosting uses its library defaults other than random_state. The grid-search implementation searches learning rates 0.003,0.03,0.1 and depths 3,4,6 with five-fold stratified training-only CV and balanced accuracy. Nine settings × five folds for each of three models implies 135 candidate-fold fits plus refits if run as supplied. No retained CV result table was found; report the selected file and implementation, not invented tuning scores.

The selected settings differ from fallback hard-coded settings used if `--params` is omitted. Saved evaluation configs explicitly use `classifier_params.json`. Most remaining tree parameters are library defaults. Exact historical package versions therefore matter; requirements pins are a proposed environment unless a run-specific lock proves installation. CPU classification is configured for XGBoost, CatBoost and LightGBM with limited threads; old hardware notes identify an RTX 4050 laptop but do not document every fit's runtime hardware.

### 6.11 Results: how to interpret every condition

The table below uses the 0–1 metric scale. Overall means/SDs pool four classifier families and five seeds. They are descriptive averages over 20 fits, not 20 independent data replications.

| Condition | f1 | balanced_accuracy | sensitivity | specificity |
| --- | --- | --- | --- | --- |
| original | 0.879297 ± 0.029281 | 0.921766 ± 0.018648 | 0.848913 ± 0.036291 | 0.994620 ± 0.001604 |
| augment | 0.857331 ± 0.016905 | 0.895346 ± 0.012885 | 0.794565 ± 0.025891 | 0.996126 ± 0.001150 |
| minority | 0.852498 ± 0.009458 | 0.938073 ± 0.008385 | 0.889130 ± 0.017132 | 0.987016 ± 0.001089 |
| synthetic | 0.461444 ± 0.029513 | 0.815328 ± 0.025955 | 0.723913 ± 0.049923 | 0.906743 ± 0.003452 |
| smote | 0.883911 ± 0.025212 | 0.945481 ± 0.016626 | 0.900000 ± 0.034118 | 0.990961 ± 0.003548 |
| smotenc | 0.867032 ± 0.016776 | 0.943174 ± 0.013782 | 0.897826 ± 0.030007 | 0.988522 ± 0.003695 |


**Original:** mean positive F1 0.879297 and balanced accuracy 0.921766. This is the primary real-only reference. Its specificity is already high, 0.994620.

**Full local augmentation:** F1 falls to 0.857331, balanced accuracy to 0.895346 and sensitivity to 0.794565, while specificity rises slightly to 0.996126. Adding rows did not improve the mean of these classifier conditions. The positive F1 change is −0.021965, or −2.197 points. A claim that this local run improves the original-only condition is contradicted by the saved aggregate.

**Minority-only:** balanced accuracy rises to 0.938073 and sensitivity to 0.889130, but specificity falls to 0.987016 and F1 falls to 0.852498. It finds more positives while increasing false positives enough to reduce F1. This is a tradeoff, not a contradiction between metrics.

**Synthetic-only:** F1 is 0.461444, balanced accuracy 0.815328, sensitivity 0.723913 and specificity 0.906743. The much larger false-positive rate matters when there are 697 real negatives and only 46 positives. This is evidence that this generated pool does not substitute well for real training under these models; it is not a verdict on every EPIC model or dataset.

**SMOTE:** F1 0.883911 and balanced accuracy 0.945481 are the highest pooled means among the six conditions. Its F1 advantage over original is about 0.004615, a small descriptive difference requiring matched per-classifier/seed analysis before a robust claim. Its category interpolation and larger augmentation budget must be disclosed.

**SMOTENC:** balanced accuracy 0.943174 and sensitivity 0.897826 exceed original-only, but F1 0.867032 is lower. A schema-aware sampler can have this metric tradeoff without an implementation error.

Per-classifier reporting matters: original CatBoost mean F1 is about 0.9115, whereas original GradientBoosting is about 0.8409. Pooling those creates dispersion from different model families. Use `epic_recomputed_by_classifier.csv` for means and sample SDs of each model-condition combination. An SD of zero for a deterministic model/configuration is possible and is not five-fold cross-validation.

### 6.12 Correlations and marginal distributions

**Pearson correlation** is covariance divided by the product of standard deviations. It measures linear association between two numerical columns, from −1 to +1. It is undefined for a constant column. It does not measure all forms of dependence and does not imply causation.

**Cramér's V** summarizes categorical association from a contingency table: `sqrt(chi_squared / (n × min(r−1,c−1)))`. Values are typically between 0 and 1 when defined. Here the statistic is uncorrected and the chi-square call disables the continuity correction. If the contingency table has only one level in an axis, the denominator is zero and the pair stays undefined.

B calculates these matrices separately for negative and sick rows. It compares real training and synthetic matrices using the mean absolute difference over finite, upper-triangle off-diagonal pairs. The diagonal is excluded; missing/undefined correlations are not replaced by zero. Smaller mean difference means more similar pairwise association under that statistic, not a proven realistic joint distribution.

| Class | Pearson mean absolute error / defined pairs | Cramér's V mean absolute error / defined pairs |
| --- | --- | --- |
| negative | 0.176908 / 15 | 0.050870 / 120 |
| sick | 0.175534 / 15 | 0.044742 / 66 |

There are 15 possible numerical pairs for six fields. The categorical comparison includes fewer defined pairs than all 210 combinations because many flags are constant in a class or synthetic subset. Compare this coverage before calling the small categorical error a comprehensive fidelity score.

A **histogram** groups values into bins; `density=True` scales the total area to one. B uses common real/synthetic bin edges per numerical feature and class. It is for distribution shape, not raw sample-count comparison.

### 6.13 Additional data-quality findings from this audit

The real age range is 1–455 and synthetic age range 10–92. Do not silently remove age=455 from one arm and leave the other unchanged; if a cleaning rule is introduced it becomes a new experiment. The stored table lacks a raw provenance trail explaining that outlier.

The synthetic TSH minimum 0.001 is below training minimum 0.005 in one row. One synthetic T4U value exceeds training maximum: synthetic max 2.87 versus real max 2.12. These are range diagnostics, not clinical plausibility judgments. Falling inside a real range also does not guarantee a valid record.

Synthetic `TT4_measured` is true in all 1,000 rows, while real training has 141 false values. Real referral-source counts are other=1,721 and SVI=819; synthetic counts are other=405 and SVI=591, with the three remaining sources nearly disappearing. This is measurable feature-distribution shift. It is a plausible quality concern, but the audit did not causally prove which shift caused downstream changes.

The authors' separate supplied file has 1,017 rows and its older audit reports 33 duplicates and 274 exact training matches. Do not apply those numbers to local Qwen data. The local final set has one duplicate excess and four training matches. Provenance must distinguish `reference/authors_Sick_samples.csv` from `runs/local-epic/synthetic.csv`.

### 6.14 Every implemented ablation and optional baseline

| Prompt variant | Purpose | Completed corresponding 1K/evaluation output found? |
| --- | --- | --- |
| epic | Balanced grouped CSV with unique category mapping | Yes, local-epic |
| csv-grouped | Remove mapping, retain grouping/balance | No |
| csv-balanced | Balanced shuffled raw-category CSV | No |
| csv-original | Random examples with original class proportions | No |
| csv-single | One class per call, alternates classes, equal total demo count | No |
| sen-balanced | Balanced examples in `column is value` sentences | No |
| explicit | EPIC plus explicit generation instruction | No |
| no-description | EPIC with variable-description block omitted | No |

“Implemented” and “evaluated” must remain separate. The smoke generation exists and tests local operation, but it is not an independent full-size replication of every variant.

Optional adapters exist for **TVAE** (variational autoencoder), **CTGAN** (conditional generative adversarial network), **CopulaGAN** (copula/GAN-based synthesizer), and **GReaT** (language-model-based tabular generation, here using DistilGPT2). Their existence does not establish training completion. SDV baseline training defaults to 300 epochs; README's GReaT example uses 85. No corresponding completed neural-baseline generation/evaluation folders were found. CTAB-GAN, CTAB-GAN+, TabDDPM, LITO and CuratedLLM are discussed in README as out of scope or requiring integration, not completed comparisons.

### 6.15 Changes from the published/released setup

Document local Qwen substitution, recorded quantization, 24 rather than 120 demonstrations, temperature 0.7, serial raw-completion requests, concise descriptions, collision-checked category mapping, no within-prompt row repetition, training-only category encoding, malformed/nonfinite/unknown-category rejection, bounded calls and context checks. These make a transparent adaptation, not an exact numerical reproduction of the original paper.

The PowerShell launcher also changed: it now accepts `-PythonExe` and `-CheckOnly`, resolves a single absolute epic-free interpreter, validates its existence, imports required dependencies before execution, and invokes every stage using that interpreter. This fixes a PATH/profile issue that could run base Anaconda instead. The exact before/after diff is in 04. It changes environment selection; there is no recorded causal experiment showing a model-score effect from the launcher fix.

### 6.16 Paper-safe interpretation

“We implement a local quantized-Qwen adaptation of EPIC on the released Sick split. One completed generation produced 1,000 schema-valid rows. Across four downstream classifiers and five training seeds, full augmentation did not improve pooled positive-class F1 over real-only training. Minority-only augmentation improved sensitivity and balanced accuracy while lowering F1, and synthetic-only training transferred poorly.”

This can support a reproduction/analysis study if positioned around local-model constraints, validity, fidelity and downstream utility. It does not substantiate a new EPIC algorithm or a full reproduction across the original paper's datasets and generators. Independent generation seeds, per-classifier uncertainty, label/feature review and matched sample budgets would strengthen it.

## 7. Project C: margin-guided versus random-reference augmentation

### 7.1 The research question and the evidence hierarchy

Root: `E:\CodexProjects\thew-x20`. Comparison mirror: `E:\CodexProjects\moved_from_c_backup\thew-x20-original`.

The question is narrower than “Does an LLM generate text?” It asks whether a classifier's uncertainty signal helps select more useful **real prompt references**, at the same synthetic class budget, compared with random references.

Use evidence in this order: stored prediction arrays and their aligned splits; per-run JSON metrics; paired-seed tables recomputed from those records; current scripts; saved narrative summaries. A script may have evolved after an old result. A status log may have stopped being updated. In this project both issues occur.

The protocol in `outputs/paper_experiment_protocol.md` is prospective relative to an already-observed pilot. It proposes future controls; it cannot retroactively turn observed exploratory runs into preregistered confirmation.

### 7.2 Three datasets and the split distinctions

#### DAIR.AI Emotion pilot

The status record reports that the user's 416,809-row `merged_training.pkl` was checked against the upstream unsplit emotion release and matched 416,123 unique text/label pairs. After normalized text deduplication and removal of conflicting labels, the record reports 371,527 unique consistent texts. These provenance statements are inherited historical audit records; this audit checked the saved splits rather than redownloading and re-verifying the complete upstream dataset.

The notebook normalizes whitespace, strips text and label strings, creates a casefolded normalized `key`, removes rows whose normalized text appears with conflicting labels, then deduplicates by key. It samples a stratified 6,000-text pilot and splits 70/15/15 into 4,200 train, 900 validation and 900 test using seed 42.

| Label | Train | Validation | Test |
| --- | --- | --- | --- |
| anger | 592 | 126 | 127 |
| fear | 447 | 96 | 96 |
| joy | 1,462 | 314 | 313 |
| love | 276 | 59 | 59 |
| sadness | 1,312 | 281 | 281 |
| surprise | 111 | 24 | 24 |

The pilot retains natural class proportions; it is not A's artificial Love/Surprise-only imbalance. The observed train largest/smallest ratio is about 13.171:1. The previously inspected test result for a selected class-weighted BERT has macro-F1 about 0.9547. It is historical evaluation and cannot be presented as fresh confirmation after later prompt tuning.

#### TweetEval Emotion

This is the four-class **emotion** configuration, not A's three-class sentiment configuration. The saved manifest records revision `b3a375baf0f409c77e6bc7aa35102b7b3534f8be`. Twenty-five repeated training texts are removed; validation and test row memberships remain official.

| Label | Train | Validation | Test |
| --- | --- | --- | --- |
| anger | 1,400 | 160 | 558 |
| joy | 683 | 97 | 358 |
| optimism | 294 | 28 | 123 |
| sadness | 855 | 89 | 382 |
| Total | 3,232 | 374 | 1,421 |

Training imbalance ratio is about 4.762:1. Validation optimism has only 28 examples, making its F1 sensitive to a few errors. The preparation script normalizes whitespace in every split and drops same-label training duplicates. It queries the upstream revision after loading rather than explicitly passing that revision into the dataset load; the recorded revision is useful provenance, but a future rerun should pin it directly.

#### TREC-6

The project prepares question classification from `train_5500.label` and `TREC_10.label`. Coarse label meanings: ABBR=abbreviation, DESC=description/definition, ENTY=entity, HUM=human/person, LOC=location and NUM=numeric answer. The script obtains coarse labels from the text before the colon in the original fine-grained label.

The saved manifest gives 5,452 original training lines, 5,380 after duplicate text-label removal, no additional conflict removal, and 5,369 after excluding 11 texts overlapping the original test set. It then makes a stratified 85/15 training/validation split with seed 42: 4,563/806. Original 500-question test membership is retained. The filename's “5500” is not the actual row count reported by the parser.

| Label | Train | Validation |
| --- | --- | --- |
| ABBR | 71 | 13 |
| DESC | 974 | 172 |
| ENTY | 1,058 | 187 |
| HUM | 1,033 | 182 |
| LOC | 699 | 124 |
| NUM | 728 | 128 |

Train largest/smallest ratio is about 14.901:1. The 13 validation ABBR examples are a small denominator. The saved original study reports no test performance for this stage. Looking up test keys for overlap safeguards is a limited use of held-out input information, so “test labels/performance unused for model selection” is more precise than “test data never accessed.” My added audit tabulates saved split membership/counts, but does not evaluate a new model on these test labels.

All three saved split pairs are disjoint by normalized key, and no within-split duplicate keys were found in this audit. That prevents this exact overlap mechanism; it does not establish independence by author, event, near paraphrase or source group.

### 7.3 Final-classifier settings and traditional controls

Common C settings are `bert-base-uncased`, 128-token maximum, batch size 16, three epochs, AdamW learning rate 2e-5 and weight decay 0.01, gradient norm clip 1.0, and final-epoch scoring. Each method initializes a fresh pretrained classifier with the training seed. It does not continue training the previous method's model.

Ordinary BERT uses cross-entropy. Class weighting uses inverse-frequency weights. Full random oversampling balances every class to the largest count; undersampling reduces every class to the smallest. Focal loss uses gamma=2. The matched repetition control instead repeats real rows according to the **same capped class budget** as LLM augmentation, offering a fairer row-budget comparison than full oversampling.

These runs report training rows, optimizer steps and training minutes. Equal epochs leave different step budgets when training sizes change. The scorer and generator add costs beyond the final BERT fit. Some scripts reuse notebook function cells by numeric cell index, so changing the notebook's cell layout can silently change or break their dependency. The source appendix preserves those cell numbers for inspection.

### 7.4 Auxiliary scorer: what is held out, and from what

The auxiliary BERT fits on 75% of the **training split**. The remaining 25% of that training split forms the reference-scoring pool. Approximate exact sizes under the saved split construction are DAIR 3,150 scorer-train/1,050 anchors, TweetEval 2,424/808, and TREC 3,422/1,141. Saved scorer JSON files record the completed values.

“Held-out anchors” here means unseen by the auxiliary scorer during its fit. They are still legal training data for the final classifier. They are not the final validation or test examples. The final predictor trains on all real training rows plus augmentation.

For every anchor, the record contains text, true label, normalized key, encoded label, p_true, strongest rival label, p_rival and margin. Positive margin means the scorer ranks the true label above every rival. Misclassified anchors are excluded from the margin-reference pool.

### 7.5 Strict selection and fallback: the exact algorithm

The original reusable notebook uses strict `0 < margin <= 0.30` and skips classes without eligible anchors. The completed continuation changed this: for each class, sort **all positive-margin** anchors ascending, count strict examples, and choose the first `max(5, min(30, strict_count))` if enough exist. Each selected row is marked `strict_boundary` or `lowest_positive_margin_fallback`.

If strict_count=0, it still takes up to five positive-margin rows. If strict_count=2, it takes five total, of which three are fallback. If strict_count=40, it takes 30. Sampling supplies up to three selected references per generation batch. A fallback example can have a very high positive margin; the name “boundary” does not make it near the decision boundary.

The saved availability table is:

| Dataset | Selected strict rows | Selected fallback rows | Total selected |
| --- | --- | --- | --- |
| DAIR | 7 | 23 | 30 |
| TweetEval | 24 | 1 | 25 |
| TREC | 2 | 28 | 30 |

DAIR Surprise has zero strict references among its five selected rows. TREC ABBR, HUM, LOC and NUM have zero strict references. Those classes do not test true strict-boundary references. Availability includes the largest class too, even if no synthetic rows are generated for that class; counts of selected anchors are not counts of reference uses in prompts.

### 7.6 Synthetic class budgets

The general plan is `min(largest_training_count − class_count, 100)` for each class. It is capped gap filling, not complete balancing.

| Dataset | Per-class addition plan | Total synthetic | Final training rows |
| --- | --- | --- | --- |
| DAIR | 100 each anger/fear/love/sadness/surprise; 0 joy | 500 | 4,700 |
| TweetEval | 100 each joy/optimism/sadness; 0 anger | 300 | 3,532 |
| TREC | ABBR 100, DESC 84, ENTY 0, HUM 25, LOC 100, NUM 100 | 409 | 4,972 |

The phrase “409 examples per class plan” in the status prose should be read as **409 total apportioned by class gaps**, not 409 examples for every class. Matched repetition uses the same per-class additions. Some repetition implementations sample without replacement when the available real class exceeds the requested addition; they still append copies of already-present real rows, so this remains repetition relative to the full training set.

### 7.7 Prompts, decoding and overlap protection

Margin prompts include up to three reference records with label, rival, probabilities, margin and selection reason. They tell Qwen to preserve class distinctions, match language/domain/length/register, avoid copies and return a JSON `texts` array. DAIR continuation and TweetEval use temperature 0.8 and initial num_predict=1600. TweetEval JSON retry logic allows four attempts; retry seeds add 100003 per attempt and later attempts use 2400 tokens. TREC's first generation uses temperature 0.7.

The generation loop requests batches of up to ten rows, checks a normalized whitespace/casefold key against real train/validation/test keys and previously accepted synthetic keys, and saves accepted rows and prompts incrementally. It stops with a shortfall error if the per-class budget is not met. This is stronger exact-overlap protection than A's target-pool-only exact-string check.

These checks do not remove semantic paraphrases or verify intended labels. The class in each generated record is the requested class, not an independently adjudicated true label. All relevant generated-data comparisons are marked unreviewed. Prompt text itself asks the generator not to follow instructions embedded in reference data; that is a prompt precaution, not an evaluated robustness result.

### 7.8 The control history: every change that affects interpretation

| Stage | Random-reference eligibility | Other differences | Interpretation |
| --- | --- | --- | --- |
| First DAIR random control | Full real training split | Margin uses scorer-unseen subset and richer records/guidance | Pool and prompt confounds |
| Same-pool random | Same scorer-held-out subset | Includes scorer-misclassified rows; simpler fields/guidance | Removes source-pool mismatch, retains correctness and prompt confounds |
| Correct-pool random | Same subset, restricted to margin>0 | Still uses different record fields/guidance from margin arm | Corrects eligibility; does not fully isolate ranking |
| Controlled TREC v2 g101 | Same positive-margin eligibility, matched record fields and prompt wording | Low/random/high margin selection varies | Better isolation of reference policy; one generation/training seed |
| Style-matched TweetEval g101 | Positive-margin random references, explicit surface matching | Different generation policy and later confidence selection | New exploratory method, not a replication of old margin arm |

The exact prompt audit found 142/150 random DAIR reference uses and 67/90 random TweetEval reference uses were correctly classified in the older same-pool controls. These are **reference uses**, including possible reuse, not necessarily distinct anchor counts. Margin references all had positive margins. Correctness filtering could therefore explain some apparent benefit credited to ranking.

Even the corrected old-generation comparisons still change whether probabilities/rival/selection information appears in the prompt and the generation guidance. Correct-pool results are more informative than the older controls, but they are not a pure “change ranking only” ablation. This is visible directly in `run_controls.py`, `run_tweeteval_augmentation.py` and `run_trec6_margin.py`.

### 7.9 DAIR single-seed comparisons

Saved seed-42 validation macro-F1:

| Method | Macro-F1 | Training rows |
| --- | --- | --- |
| Matched real repetition | 0.9684 | 4,700 |
| Class-weighted BERT | 0.9601 | 4,200 |
| Margin-reference LLM + BERT | 0.9570 | 4,700 |
| Focal-loss BERT | 0.9566 | 4,200 |
| Ordinary BERT | 0.9554 | 4,200 |
| Full random oversampling | 0.9527 | 8,772 |
| Full-pool random-reference LLM | 0.9477 | 4,700 |
| Weighted BERT + margin LLM | 0.9452 | 4,700 |
| Weighted BERT + full-pool random LLM | 0.9403 | 4,700 |
| Random undersampling | 0.7121 | 666 |

Same-pool unfiltered random LLM scores 0.9447. Correct-pool random LLM scores 0.9563. Thus the old margin advantage +0.0123 over unfiltered same-pool random becomes about +0.000677 against the corrected control for seed 42. Do not cite the former as proof of ranking benefit.

Matched repetition outperforms both LLM conditions in this seed, so successful text generation is not enough to claim added semantic value beyond exposure. Combining weights with margin synthetic rows also performs worse than weighting alone; training interventions can interact negatively.

### 7.10 TweetEval single-seed comparisons

| Method | Validation macro-F1 | Optimism F1 where reported |
| --- | --- | --- |
| Ordinary BERT | 0.7545 | 0.5600 |
| Unfiltered same-pool random LLM | 0.7483 | 0.5357 |
| Matched real repetition | 0.7411 | 0.5091 |
| Margin-reference LLM | 0.7285 | 0.4828 |
| Class-weighted BERT | 0.7267 | 0.5357 |
| Correct-pool random LLM | 0.7155 | See per-run JSON |

Margin minus old random is about −0.0198; margin minus corrected random is about +0.0130. The random condition change reverses the sign, partly because it also generates a new synthetic set. Neither margin nor either random arm beats the ordinary seed-42 BERT baseline. This is why results must retain the exact generation condition name.

### 7.11 TREC single-seed comparisons

Ordinary BERT macro-F1 is 0.9163, class weights 0.9325, matched repetition 0.9094, old margin LLM 0.9232 and correct-pool random LLM 0.9523. Random minus margin is +0.029105; random minus class weights is about +0.0199. ABBR F1 is 0.7500 ordinary, 0.8148 weights, 0.7222 margin and 0.8889 random, on only 13 validation ABBR examples.

The stored 5,000-draw class-stratified bootstrap interval for random minus margin is approximately [0.0007,0.0548]. For random minus weights it is approximately [−0.0042,0.0462]. The first excludes zero conditional on these models; the second includes zero. Neither covers new synthetic draws or model training variability.

A later ordinary TREC BERT seed-43 run scores 0.952334, close to the old random-generation seed-42 score. This illustrates training variability and why it is unsafe to present a one-seed LLM-versus-baseline gap as a stable treatment benefit. There is no full matched five-seed table for all traditional baselines in the provided artifacts.

### 7.12 The latest five-seed corrected-pool results

The current saved artifacts contain complete paired training seeds 42–46 for margin versus correct-pool random on all three datasets. The research status log ends earlier and incorrectly implies some of these remain unfinished. The completed JSON files and probabilities, rather than that older line, establish the current available result set.

| Dataset | Pairs | Margin mean ± SD | Correct-random mean ± SD | Paired difference mean ± SD |
| --- | --- | --- | --- | --- |
| dair_emotion | 5 | 0.951702 ± 0.003821 | 0.947262 ± 0.006829 | +0.004440 ± 0.006066 |
| trec6 | 5 | 0.935114 ± 0.010065 | 0.947856 ± 0.004576 | -0.012742 ± 0.012782 |
| tweet_eval_emotion | 5 | 0.730640 ± 0.011270 | 0.721105 ± 0.017718 | +0.009535 ± 0.016810 |


The paired differences by seed are:

| dataset | 42 | 43 | 44 | 45 | 46 |
| --- | --- | --- | --- | --- | --- |
| dair_emotion | +0.000677 | +0.004828 | +0.014743 | -0.000189 | +0.002143 |
| trec6 | -0.029105 | +0.003014 | -0.003234 | -0.015260 | -0.019126 |
| tweet_eval_emotion | +0.012989 | +0.025213 | +0.022149 | -0.016573 | +0.003896 |


Scores use the 0–1 scale. Expressed in percentage points, the mean margin-minus-correct-random difference is **+0.444 ± 0.607 points on DAIR**, **+0.953 ± 1.681 points on TweetEval**, and **−1.274 ± 1.278 points on TREC**. The SD here is the SD of paired differences, not the SD of either method individually.

Margin wins four of five training seeds on DAIR and TweetEval and one of five on TREC. TweetEval's pair signs still vary. These means describe fixed generated datasets under downstream training variation; they do not establish that independently regenerating synthetic text preserves the ranking. Older `seed_comparison.csv` and `training_seed_results.csv` are not equally current; the complete corrected-pair table plus per-run files is the appropriate basis for this comparison.

The old unfiltered-control five-seed table gave margin-minus-random mean about +0.0106 on DAIR and −0.0043 on TweetEval. Keep it as control-history evidence. Do not substitute it for the corrected eligibility analysis, especially since TweetEval's average sign changes.

### 7.13 Controlled TREC generation seed 101: the later mechanism check

`work/generate_controlled_references.py` freezes the scorer/split and generates three new TREC sets: low-positive-margin, random eligible and high-margin. All use the same record fields `text,label,rival,p_true,p_rival,margin`, class descriptions, prompt wording, per-class plan and decoder policy. It explicitly says high-margin records can be interpreted using the same neutral margin definition; it does not describe every reference as uncertain.

Low-margin selection uses up to 30 lowest positive examples with the same strict-count/minimum-five policy; random uses all correctly classified anchors; high-margin uses the 30 largest positive margins. Up to three are sampled per batch. Reference seed is `generation_seed ×100000 + class_index×1000 + batch`; decoding seed is `generation_seed + class_index×1000 + batch`, with +100003 retry offsets. Temperature is 0.7, output limit 1200, forced CPU inference (`num_gpu=0`) and four threads. Prompts include SHA-256 hashes and reference keys in logs.

Each condition produces 409 examples, and each seed-42 final BERT fits 4,972 rows for 933 steps. Saved validation macro-F1:

| g101 condition | Macro-F1 |
| --- | --- |
| Low-positive-margin references | 0.903776 |
| Random eligible references | 0.936390 |
| High-margin references | 0.919009 |

Low minus random is −0.032614, or −3.261 points. High minus random is −0.017381, or −1.738 points. The controlled random arm is best of these three in this one generation/training pair. Do not pool these scores with the old generation into a single five-seed estimate: the synthetic datasets, prompt and generation seed differ. This follow-up strengthens evidence that low margin is not uniformly useful, but independent paired generation replications remain necessary.

### 7.14 Style-matched TweetEval and confidence selection

`generate_style_matched_tweet.py` estimates hashtag rate, mention rate and median whitespace-word length separately from each real training class. It samples desired hashtag/mention flags per new example, includes those instructions in the prompt and accepts an output only when regex checks match the requested flags. It uses correctly classified random real references, temperature 0.8, CPU inference, four threads, up to five texts per call, three retries and seed 101. It produces 300 unique rows: 100 each joy/optimism/sadness.

This is an actual change to generator policy, motivated by the observed mismatch. It matches selected surface statistics, not the full language distribution. Hashtag and mention flags are sampled independently, so the joint relationship between them is not necessarily preserved. On resume, the script restarts its per-class RNG sequence; resumption history is another reason to retain exact output hashes and prompts.

`select_confidence_filtered_tweets.py` scores those 300 candidates with the saved real-only TweetEval BERT on CPU at max_length=128. It ranks intended-label probability within each class and retains the top 50 per class (150 total). A comparison set samples 50 per class at random from the **same** 300 candidates. It saves all scores and predicted labels, so selection is auditable.

The mean teacher probability is 0.968604 in selected rows versus 0.797653 in random rows. This difference is expected by construction; it is not independent evidence of correct human labels. Teacher optimism probability averages 0.931063 selected versus 0.584280 random, but the teacher can still be biased or confidently wrong.

One downstream file exists for `confidence_top50_g101_len64_cpu_seed42`: macro-F1 0.751311, 150 synthetic rows, 3,382 total training rows, 636 steps, max_length=64, CPU. The older baseline used length 128 and older augmentation used 300 rows. A random-150 selection CSV exists, but no matching saved final-classifier result for it was found. Consequently this does **not** establish that confidence filtering improves a matched random-150 control or that it beats a matched length-64 real-only baseline. It is an exploratory completed arm with missing controls.

### 7.15 Quality diagnostics, and their limitations

DAIR/TweetEval `quality_audit.py` uses character 3–5-gram HashingVectorizer with 2^17 features, nonnegative hashing and L2 normalization. It finds each text's maximum cosine similarity to any real training text. Median nearest similarity is about 0.367 for DAIR real validation, 0.267 for margin synthesis and 0.280 for old random synthesis. TweetEval counterparts are about 0.260,0.225,0.231. No old generated example exceeds 0.9 in that diagnostic.

A **character n-gram** is a sequence of n adjacent characters. Shared n-grams approximate surface overlap, not semantic equivalence. Hashing maps many possible n-grams into fixed bins, allowing collisions. The TREC surface audit instead fits character TF-IDF, so do not treat the three datasets' nearest-similarity numbers as one uniformly implemented embedding score. TF-IDF weights common versus distinctive n-grams; it is distinct from BERT or MiniLM semantic embeddings.

TREC median nearest similarities are about 0.346 real validation, 0.327 margin and 0.332 corrected random. Word-length medians and question-mark rates are also reported. These checks assess copying and style, not label correctness.

TweetEval real training hashtags occur in roughly 42–48% of examples by class, while old margin synthetic joy/optimism/sadness have 0%. Real mentions occur in roughly 32–47% for those classes, while margin synthesis has 0–1%. The style audit is a descriptive source comparison; it does not prove that missing hashtags caused an F1 loss. A causal style experiment would hold the other generation factors and budgets fixed.

The old method-blinded label/naturalness sheet has 260 items with **zero completed judgments**. The new controlled TREC sheet has 225 items and **zero reviewer labels or naturalness scores**. Prepared review forms are not a completed human evaluation. No inter-annotator agreement or label-accuracy percentage can be reported from them.

### 7.16 Resource-safety and reproducibility changes

The status file records a seed-45 attempt stopped at a thermal threshold, without a saved result at that time. Current seed-45/46 JSON files subsequently exist, so “seed 45 not saved” describes the old stopped attempt, not the final state.

The current replication runner adds CPU overrides and thread selection, an optional token-length override, method/dataset/seed selectors, extra synthetic input support, a GPU memory fraction of 0.75, 0.15-second per-step pauses, temperature checks every ten batches, pause at 79°C and resume at 70°C. It checkpoints between epochs, storing model/optimizer/history, epoch and Torch/DataLoader/CUDA RNG states. It deletes the temporary checkpoint when the fit completes.

These settings alter resource use and wall-clock time; max-length and device changes can also alter predictions. Most older JSON files do not record max_length/device, while the newer confidence-filter run does. Do not infer the current default was explicitly logged for every historical fit. Epoch-boundary checkpoints also do not preserve arbitrary mid-epoch progress, and all random state sources are not independently documented. A remaining `.pt` checkpoint is not a completed result; use final JSON/probability evidence.

### 7.17 Mirror comparison: what changed and what cannot be recovered

The comparison finds 72 current-only files, 29 differing files, 232 byte-identical small files and 13 same-size large binaries whose bytes were not compared. There were no mirror-only files in the audited inventory. “Same size” does not establish identical weights. The inventory hashes small artifacts; it intentionally leaves large model hashes blank.

Many source changes replace the previous C-drive project paths and Downloads notebook dependency with the current E-drive `external` paths. These relocation edits do not themselves imply different algorithms. Substantive additions include the controlled generation script, style matching, confidence filtering and resource-safe replication logic. New outputs include the controlled TREC g101 runs, later TREC seed replications, a TREC seed-43 ordinary baseline and the confidence-filtered TweetEval arm. Exact diffs and every added filename are in 04 and `mirror_comparison.csv`.

The mirror is a snapshot, not a version-control history. It cannot establish the chronological order of every intermediate edit or why an unlogged change was made. The main project also includes preserved external inputs absent in that mirror, so “current only” sometimes means relocated/copied evidence rather than newly executed research.

### 7.18 What C supports now

The strongest defensible framing is a **controlled empirical study of when reference-selection heuristics help or fail**. Correcting eligibility reduces the original DAIR effect, outcomes vary by dataset, strict boundary anchors are scarce, and the newer prompt-matched TREC comparison favors random selection in one run.

It does not establish a universally superior margin-guided method. The complete corrected five-training-seed comparisons are valuable, but still hold generated text and scorer fixed and retain old prompt-information confounds. The controlled g101 result improves the mechanism test but is one generation seed. Human judgments and full matched baseline replications are still missing.

## 8. How to navigate every kind of file

### 8.1 File extensions and the columns inside them

| Artifact | What it means | What it cannot establish alone |
| --- | --- | --- |
| `.py` | Python implementation; functions/classes define behavior | That a particular source revision generated an old CSV |
| `.ipynb` | Notebook containing Markdown, code and possibly saved outputs | That every cell was executed in order in the current environment |
| `.csv` | Plain-text rows/columns; inspect header, scale, split and method name | Method provenance if no config links it to execution |
| `.json` | Structured settings, metrics, mappings or metadata | Completion unless content describes an actual final result |
| `.jsonl` | One JSON record per line, useful for calls/prompts/batches | That every request returned usable rows |
| `.npy` | NumPy numeric array, often validation class probabilities | Class/row alignment without matching split and class ordering |
| `.safetensors` | Serialized trained model weights | Performance or training history without tokenizer/config/results |
| `.pt` | PyTorch state/checkpoint, possibly partial training | A completed fit if final metrics are absent |
| `.pkl` | Python pickle containing data or objects | Safe portability or schema meaning without inspection |
| `.label` | TREC's original label-plus-question text format | The preprocessed split membership after cleaning |
| `.log` | Recorded events, HTTP calls, warnings/errors or server output | Exact experiment settings when startup arguments were not recorded |
| `.png`, `.pdf` | Rendered figures | The statistical validity of a caption or an effect claim |
| `.tex` | LaTeX source for paper tables | A new experiment; it is a formatted view of saved tables |
| `requirements.txt` | Requested package dependencies | Proof those exact versions ran a historical experiment |
| `README.md`, status/protocol Markdown | Instructions, interpretation and planned work | Current completion state when stale |
| `AUTHORS_LICENSE` or other license text | Terms attached to supplied source/reference material | A license for unrelated datasets or generated content |

Core result columns:

* `Task` / `dataset`: dataset configuration, not necessarily the same task when names resemble one another.
* `IR` / `Imbalance_Ratio`: requested imbalance setting in A; achieved counts may differ.
* `Method` / `method`: exact treatment identifier. Preserve eligibility and generation suffixes.
* `Seed` / `training_seed`: seed policy for the particular pipeline, explained above.
* `Macro_F1`, `Minority_F1`, `Majority_F1`, `G_Mean`, `Accuracy`: A percentages; `_mean`/`_std` are grouped seed statistics.
* `f1`, `balanced_accuracy`, `sensitivity`, `specificity`: B binary positive-class metrics on 0–1 scale.
* `n_train` / `train_rows`: actual fit rows, including repeated rows; not unique sample count.
* `synthetic_rows`: accepted added rows in the associated arm; check whether matched real repeats are counted separately.
* `optimizer_steps`: training updates; not epochs and not batches per epoch.
* `train_minutes`: timed interval defined by the training function; cooling/waiting may be included.
* `per_class_f1`: mapping from class name to its F1; inspect LabelEncoder/config ordering for arrays.
* `training_losses`, `losses`, `history`: mean batch training loss by epoch, depending on the script. Different loss definitions and weights have different scales.
* `generation_seed_varied=False`: explicitly says downstream seed replication reused a fixed synthetic dataset.
* `key`: normalized text for overlap comparisons. It is not a semantic embedding.
* `selection`: strict-boundary versus positive-margin-fallback explanation for a reference, not a human label review.
* `teacher_p_intended`: teacher probability of the requested label, not verified label correctness.

A function string such as `<function evaluate at 0x...>` appears in B configs because the argument namespace includes a callable and the serializer converts it to text. The memory address is an execution artifact; it is not a hyperparameter, model ID or meaningful reproducibility key.

### 8.2 Project A source responsibilities

`build_imbalanced_dataset` loads official train/test splits and samples counts. `augment_ros` repeats target rows. `simple_eda_transform` and `augment_eda` implement perturbation. `OllamaGenerator` manages server/model selection, request/parsing, cache and fallback. `build_generation_prompt` constructs the condition-specific message. `EmbeddingHelper` embeds texts, retrieves non-target examples and ranks generated candidates. `TextClsDataset` tokenizes examples. `evaluate_base_classifier` creates a new classifier, trains and scores it. `augment_dataframe_with_llm` fills each target-class gap in A1. The Fréchet/distribution functions calculate post-hoc geometry. The plotting/LaTeX functions format collected results. `main` orders baseline fits, generation/cache population, model unloading, augmented fits and output writing.

`set_seed` resets random sources; `flush_vram` frees Python/torch caches, not the installed model files. `resolve_or_pull_model` in A1 can resolve a compatible installed model tag; a requested human-readable key is therefore weaker provenance than an actual saved model digest. V2's simpler server check does not implement the same resolve/pull behavior.

### 8.3 Project B source responsibilities

`train_data` and `test_data` align X/y. `cats` lists nonnumerical columns, including Class when present. `mapping` makes codes; `mapped` applies them. `prompt` builds the variant; `parse` reconstructs and validates rows. `generate` owns output directories, actual requests, raw responses, ledger and completion. `encoder_fit` fits categories on real training; `encode` creates numeric predictors and sick=1 targets. `models` instantiates requested classifiers; `tune` runs CV. `evaluate` constructs each training condition, fits the per-condition scaler/models and writes metrics. `quality` calculates class-conditional associations, histograms, copy counts and efficiency. `baseline` invokes optional tabular generators. `audit` checks real dataset counts/duplicates/hashes. `save_json` serializes metadata. `main` validates CLI arguments and dispatches commands.

The four `test_core.py` unit checks cover reversible unique mapping; 24 balanced nonrepeated prompt examples; unknown-category and nonfinite-number rejection; and construction of all eight variants plus sentence parsing. They test implementation properties without an LLM. Passing them would not establish generated label quality, downstream improvement, complete environments or statistical replication. Their historical execution is documented in VALIDATION; this explanatory audit did not rerun model experiments.

`run_core.ps1` is an orchestrator for audit, tests, optional tuning, generation, evaluation and quality. It checks nonzero process exits. If parameters already exist it skips tuning; file presence should not be confused with a new tuning run. `--out` generation directories are created with `exist_ok=False`, so each B generation is intended to use a fresh folder rather than silently mix runs.

### 8.4 Every Project C work script and why it exists

| Script in `work` | Role | Interpretation limit |
| --- | --- | --- |
| build_notebook.py | Creates the base BERT experiment notebook with cleaning, splitting, baselines and strict generation | Notebook construction is not model execution |
| build_llm_comparison.py | Creates continuation using saved splits/scorer and positive-margin fallback | Algorithm differs from strict-only base notebook |
| build_reusable_notebook.py | Builds a reusable experiment version | Template existence is not a completed run |
| check_notebook.py | Validates notebook schema/syntax and exercises data, margin and mocked-generation logic | Its fake generator is not a real LLM result |
| execute_llm_notebook.py | Runs the comparison notebook through its execution environment | Check saved cell outputs/errors to assess completion |
| finalize_llm.py | Verifies expected output files and creates comparison prose/notebook metadata | Its prose reflects the stage when it ran |
| run_controls.py | DAIR full-pool/same-pool/correct-pool random LLM, weighted variants and matched repetition | Mode depends on environment flags; prompts differ from margin |
| finalize_controls.py | Assembles control plot and appends a status section | Can leave the status file behind later runs |
| paired_bootstrap.py | DAIR conditional paired-item uncertainty for old random controls | Does not regenerate or retrain |
| prepare_tweeteval.py | Downloads/prepares four-class TweetEval Emotion, manifest and overlap checks | Future reproducibility should explicitly pin revision |
| run_tweeteval_baselines.py | Ordinary, class-weight and matched-repeat BERT on TweetEval | Single-seed comparison stage |
| run_tweeteval_augmentation.py | Scorer, margin/random generation and BERT; optional correctness eligibility | Correctness mode changes the random synthetic set |
| compile_pilot.py | Combines old two-dataset scores, plots and item-bootstrap uncertainty | Uses the older unfiltered random controls |
| run_seed_replications.py | Fits fixed augmentation sets across training seeds, with selectors/resource safeguards | Synthetic/scorer/split randomness remains fixed |
| summarize_training_seeds.py | Summarizes older same-pool random seed contrasts | Existing summary file may predate later results |
| summarize_correct_pool.py | Collects corrected random and margin seed-42 plus seed-43–46 records | This is the appropriate old-generation corrected pairing |
| plot_seed_differences.py | Plots saved paired training-seed differences | Plot source may be the older control table |
| quality_audit.py | DAIR/TweetEval character-hash nearest-similarity and word-length audit | Surface similarity, not semantic/human quality |
| tweet_style_audit.py | Counts hashtags, mentions and length by source/class | Regex diagnostics cannot prove a causal mechanism |
| plot_tweet_style.py | Visualizes saved style audit | Formatting stage |
| make_label_audit_sheet.py | Builds blinded generated-label/naturalness sample and separate condition key | Judgments are blank |
| audit_reference_correctness.py | Recovers exact old random prompt references and checks positive margins | Counts uses; does not adjudicate true dataset labels |
| prepare_trec6.py | Parses original question files, deduplicates, excludes test overlaps and splits | Original test not a prompt source |
| run_bert_baselines_generic.py | Configurable ordinary/weighted/matched-repeat BERT on train/validation CSVs | Defaults must match each intended comparison |
| run_trec6_margin.py | Original TREC scorer, fallback anchors, two LLM arms and final BERT | Old arms differ in prompt fields/guidance |
| trec_quality_audit.py | Character TF-IDF nearest-neighbor examples, length and punctuation | Different representation from DAIR/TweetEval audit |
| trec_conditional_bootstrap.py | Fixed-model, class-stratified TREC uncertainty | Does not cover training/generation variability |
| plot_trec_distribution.py | Training/validation class count figure | Data visualization, not a prediction result |
| plot_anchor_availability.py | Combines strict/fallback counts by dataset/class | Includes classes receiving zero generated rows |
| generate_controlled_references.py | New matched-prompt low/random/high TREC reference experiment | Only one saved generation seed here |
| prepare_controlled_label_audit.py | Samples 15 per augmented class/arm for a 225-item TREC review | Reviewer columns are blank |
| generate_style_matched_tweet.py | Matches per-class hashtag/mention frequencies and approximate length | New generator policy, not old margin replication |
| select_confidence_filtered_tweets.py | Teacher-scores one fixed pool, produces top-50 and random-50 per class | No saved matched random-150 downstream result |

The 03 source reference includes complete code for these helpers. `source_symbol_index.csv` lists function/class start and end lines, so you can locate details such as retry handling or checkpoint fields without guessing from a script name.

## 9. What changed across the work, in research order

This is a methodological ordering, not an invented complete timestamp history.

1. **C base workflow:** clean text, keep a natural-imbalance pilot, train BERT baselines, use strict positive margins for references.
2. **C operational continuation:** reuse saved splits/scorer, add fallback to reach at least five positive references per class, generate actual complete capped synthetic sets and compare ordinary/weighted fits.
3. **C equal-budget controls:** add random-reference LLM and matched real repetition, discovering repetition can be stronger.
4. **C same-pool correction:** restrict random references to the scorer-held-out anchor pool, removing full-train/pool mismatch.
5. **C correctness correction:** restrict random references to margin>0, because margin selection already excludes scorer mistakes. This changes important conclusions.
6. **C additional datasets and training replications:** add TweetEval/TREC, fixed-synthetic training seeds 42–46, per-class results and conditional bootstraps.
7. **C diagnostic work:** audit strict-reference scarcity, surface shift, hashtag/mention mismatch and prepare blinded review sheets. Review itself remains unfinished.
8. **C resource and relocation changes:** move paths to E, preserve external inputs, add thermal pauses, resume checkpoints, CPU/token-length selectors.
9. **C later controlled mechanism experiment:** generation seed 101 with equal prompt fields for low/random/high margins, then three final BERT runs.
10. **C later style/confidence experiment:** style-matched random references, teacher ranking, top-150 final BERT at length64/CPU, with matched downstream controls still absent.
11. **B adaptation stage:** implement EPIC on Sick with local quantized Qwen, compact demonstrations and explicit validation; old smoke-only documentation records this early state.
12. **B completion stage:** execute 1,000-row local generation and six evaluation conditions; retain parser failures, feature-quality diagnostics and selected tuning parameters. Fix launcher interpreter selection.
13. **A A1 stage:** artificial severe imbalance, multiple prompt designs and geometric diagnostics, saved only for Qwen/seed42 under the available run.
14. **A A2 stage:** simplified weighted-loss benchmark, two completed seeds and reduced-count-compatible cache sizes; emotion budget formula diverges from full balancing.
15. **A A3 output stage:** complete five-seed metric CSVs with stronger observed scores in some settings, but absent run-specific provenance in that output folder.

Do not merge the A/B/C sequence into an asserted real-world chronology. They are parallel lines of research with different data and completion records.

## 10. Paper direction and the claims your evidence permits

### 10.1 Choose a central paper question

For a coherent text-classification paper, C offers the cleanest central question: **When does classifier-informed reference selection help local LLM augmentation under class imbalance?** A can motivate severe-imbalance stress tests after protocol/provenance reconciliation. B is a different modality and an existing-method reproduction; it is usually clearer as a separate reproduction study or a carefully bounded secondary experiment.

This is a recommendation about framing, not an acceptance prediction. “Tier 2” has no single stable universal meaning. Venue choice needs the actual conference's scope, current call, paper category and standards. No venue ranking, deadline or acceptance probability was established in this audit.

Possible descriptive titles, not claims of novelty:

* “When Does Margin-Based Reference Selection Help Local LLM Augmentation for Imbalanced Text Classification?”
* “Reference Eligibility, Prompt Information and Synthetic Style in Imbalanced Text Augmentation”
* For B separately: “A Local Quantized-LLM Replication of EPIC on the Sick Dataset: Validity, Fidelity and Downstream Tradeoffs.”

### 10.2 Contribution versus implementation

Running BERT, using Qwen, generating synthetic rows and computing F1 are implementation components, not automatically contributions. A contribution needs a question, a distinctive controlled method or analysis, and evidence supporting a useful conclusion.

Potential evidence-backed contributions here are: identifying eligibility confounds in margin-versus-random comparisons; quantifying strict-reference scarcity; demonstrating task-dependent ranking under fixed budgets; and measuring synthetic surface-style shift. Present these as empirical findings with limits, not as proof of a universally optimal augmentation strategy.

Boundary-aware generation is already studied in **PromptMix**, which generates difficult examples and then relabels them using an LLM. Your reference-ranking workflow and lack of independent relabeling differ, but “first boundary-aware LLM augmentation” would be false. PromptMix's few-shot setup is not directly numerically comparable with your full-training TREC setup. [PromptMix, EMNLP 2023](https://aclanthology.org/2023.emnlp-main.323/).

**Text Grafting** studies near-distribution minority supervision using corpus templates and LLM filling, another relevant contrast to free generation from probability-scored references. Its supervision setting also differs from fully labeled BERT training. [Text Grafting, EMNLP 2024](https://aclanthology.org/2024.emnlp-main.219/).

The status record also cites **Class-Structure Preservation Beats Diversity**, a 2026 arXiv benchmark comparing augmentation families. Its page was checked during this audit; it is a preprint and its findings are related work, not results from your folders. Its stated evidence motivates strong embedding-based controls, but does not replace running a matched baseline here. [Preprint](https://arxiv.org/abs/2608.12340).

These are targeted checks of the papers named in the saved project, not an exhaustive novelty survey. Cite each original dataset/model/method with its official bibliographic entry before submitting.

### 10.3 Claims table: safe language and overstatements

| Evidence | Defensible wording | Wording the evidence does not support |
| --- | --- | --- |
| A3 severe sentiment/news means | “Observed gains in the saved five-seed severe-ratio benchmark” | “State-of-the-art across all imbalanced tasks” |
| A3 complete CSV arithmetic | “Reported summaries reproduce the raw-row aggregation” | “The historical experimental setup is fully reproducible” |
| B complete local generation | “1,000 schema-valid local Qwen rows were selected” | “1,000 clinically valid, independently verified records” |
| B six conditions | “Pooled full augmentation underperformed real-only positive F1” | “EPIC universally fails” |
| C corrected training seeds | “Mixed dataset-dependent results with fixed generated text” | “Five independent generation replications” |
| C g101 controlled TREC | “Random references outperform low/high selection in this paired pilot” | “Random reference selection is always optimal” |
| Character/style audits | “Synthetic surface distributions differ” | “Style mismatch is proven to cause the score drop” |
| Blinded forms with blank judgments | “A review set was prepared” | “Human evaluation confirms label purity” |
| Conditional bootstrap | “Item-sampling uncertainty for these fixed models” | “Run-to-run statistical significance of the full method” |

### 10.4 What each paper section should contain

**Abstract:** one problem sentence; one precise method/comparison sentence; dataset and replication scope; central quantitative result; honest limiting conclusion. It should be written last. Avoid leading with a cherry-picked largest gain. For C, an appropriate core finding is that corrected fixed-generation training-seed differences change sign across datasets and the prompt-matched TREC pilot favors random references.

**Introduction:** explain why rare labels matter; why local generation is attractive; why choosing examples for prompts could matter; and why current comparisons can confound reference eligibility, prompt content and generation variability. State the testable question rather than assuming the proposed method wins.

**Related work:** organize by class-imbalance treatment, local LLM generation, classifier-guided/boundary generation, prompt-reference selection and synthetic fidelity. Separate supervised classification, weak supervision and few-shot distillation settings. Do not compare scores across these settings as if they were one benchmark.

**Method:** define training/reference/validation/test sets; scorer fit and anchor pool; true-versus-rival margin equation; strict threshold and fallback; eligible random and high-margin policies; prompt fields; exact class budget; parsing/deduplication; final BERT loss/optimization. Include pseudocode and specify whether probabilities themselves are revealed to the generator.

**Experimental setup:** list dataset versions, cleaning counts, all class counts, class descriptions, exact splits/hashes, pretrained checkpoints, tokenizer, token limit, seeds by stage, quantization/digest, decoding, budgets, retry/fallback rules, training steps, hardware, software versions and selection criterion. Report validation and test separately.

**Results:** lead with the full method comparison, then corrected paired-seed differences, per-class scores and resource cost. Keep old confounded controls in an explicitly labeled ablation/history table. Use the most current per-run records. Include negative results and no-augmentation/weighted/matched-repeat controls.

**Analysis:** examine strict anchor availability, per-class effects, generated labels, near copies, style shift and low/random/high controls. Present the controlled experiment before causal wording. Include the observed evidence for a proposed explanation and the alternative sources of variability it does not eliminate.

**Limitations:** few independent generations, scorer/split fixed, small rare-class validation samples, labels unreviewed, old prompt confounds, compute mismatch, known previously viewed test, and missing A3 provenance if used. For B, one tabular dataset and local-model/demonstration substitutions are essential limits.

**Conclusion:** state the finding that survives the controls. For example: “The effectiveness of classifier-informed reference selection depends on the task and comparison protocol; reference eligibility and prompt matching materially affect interpretation.” Do not promise later experiments as if completed.

### 10.5 A concrete methods paragraph you can adapt

For the **old-generation C study**, an accurate draft is:

> We evaluated local LLM augmentation on fixed train/validation splits from DAIR.AI Emotion, TweetEval Emotion and TREC-6. An auxiliary BERT was trained on 75% of each real training split and used to score the remaining training examples. For a known label, we defined the probability margin as the predicted probability of that label minus the highest probability assigned to another label. Margin references were selected from correctly classified examples, preferring margins in (0, 0.30] and supplementing sparse classes with their lowest positive-margin examples. Generation added at most 100 examples per class according to capped class gaps. Fresh BERT classifiers were trained on the real and augmented data. We compared margin references with random references restricted to the same correctly classified anchor pool across five downstream training seeds, while holding generated texts fixed. The original prompts differed in probability metadata and guidance, so this comparison estimates the combined reference-and-prompt treatment rather than ranking alone.

For the **controlled TREC follow-up**, add a separate paragraph:

> To reduce prompt-information confounding, we generated new TREC augmentation sets using the same prompt template, reference fields, class budgets and decoder settings while varying low-positive-margin, random eligible or high-margin reference selection. This follow-up used generation seed 101 and downstream training seed 42 and is reported as a separate exploratory comparison.

Do not splice these into “all experiments used identical prompts”; that would erase a documented difference.

### 10.6 Results paragraph you can adapt

> With fixed synthetic texts and five downstream BERT training seeds, margin-reference augmentation differed from the corrected random-reference treatment by +0.00444 mean validation macro-F1 on DAIR, +0.00953 on TweetEval and −0.01274 on TREC. These differences were task dependent and did not vary scorer training, data splits or synthetic generation. In a separate TREC generation with matched prompt fields and wording, low-margin, random and high-margin references achieved macro-F1 of 0.90378, 0.93639 and 0.91901, respectively, in one downstream training seed. These results do not support a uniform benefit from low-margin reference selection.

The table should retain sample SDs and all seed-level values. This paragraph reports validation, not final test evidence.

## 11. Work required before a defensible submission

### 11.1 Resolve existing evidence gaps first

1. Recover A3's exact source, command, parameter values, model identity, cached synthetic rows and split samples. Until recovered, label its execution details unknown where appropriate.
2. Decide which project is the central paper. Keep A's artificial imbalance, B's binary tabular evaluation and C's natural multiclass setup distinct.
3. Freeze method names, prompt text, reference eligibility and metric definitions. Label A's G-Mean floor and B's positive F1 explicitly.
4. Replace stale status statements in the eventual paper with the completed records. Keep history separately; do not erase earlier controls from the research record.
5. Complete human evaluation of existing generated samples before using a label-purity claim. The prepared sheets are usable starting points.

### 11.2 Run the missing comparisons under one frozen protocol

For C, compare ordinary BERT, class-weighted BERT, matched real repetition, random eligible LLM, low-margin LLM and high-margin LLM. Match class budgets, record fields, instructions, decoder settings and downstream training. An additional embedding/retrieval baseline would help test whether generation adds value beyond structured reuse of real data.

Use several independent **paired generation seeds**, not only several downstream training seeds. Freeze or separately vary scorer seeds and train/validation partitions according to the hypothesis. Treat generation seed as an experimental unit rather than counting every downstream fit from one generated dataset as independent generator evidence. Preserve the mapping of generation seed to synthetic hashes and each training seed.

For A, fix the emotion budget in a new version, compare unweighted and weighted real-only controls, and ensure generated and repeated arms have explicitly matched intended budgets. If equal compute matters, add a fixed-update comparison alongside equal-epoch training.

For B, compare exact added-row budgets where the question is generator utility, retain schema-aware baselines, generate independent local pools, and show per-classifier/seed results. If studying compact prompts, actually execute the prompt variants with controlled context and demonstration counts. Do not silently change decoding to rescue only a failing variant.

### 11.3 Preserve evaluation independence

Choose methods with training/development data. Validation reused for repeated prompt and policy choices is development evidence. For C DAIR, the pilot test was already inspected. Use a genuinely new prespecified evaluation protocol for fresh confirmation; do not relabel the old test as untouched. For TweetEval/TREC, keep any final performance evaluation until the method/comparisons are frozen, while transparently recording existing overlap checks.

For A/B, saved experiments already repeatedly score named test sets. That does not invalidate every descriptive result, but it prevents an unqualified “never used during development” statement if those results informed later choices. A new seed alone does not reset a test set's history.

### 11.4 Human annotation protocol, explained

Sample generated examples by dataset, class and condition; blind the method name; give reviewers clear label definitions; collect intended-label correctness and naturalness separately. With two independent reviewers, report both raw agreement and a suitable chance-adjusted agreement statistic such as Cohen's kappa: `(observed_agreement−expected_agreement)/(1−expected_agreement)`, when defined. Kappa can behave oddly with highly skewed judgments, so show counts too. Do not invent a value before review.

Explain reviewer qualifications, disagreements/adjudication, sample sizes, sampling seed and whether inspected examples were used to revise prompts. Review-guided policy development must be separated from final evaluation. Naturalness on a 1–5 scale is an ordinal judgment, not automatically label correctness.

### 11.5 Reproducibility manifest to save for each new run

| Category | Required saved fields |
| --- | --- |
| Identity | run ID, timestamp with timezone, experiment version, parent run, code hash/commit |
| Data | source revision, raw/prepared hashes, cleaned row counts, label map, actual split files/IDs and per-class counts |
| Scorer | checkpoint/tokenizer revision, fit rows, training seed, parameters, scored anchors and probabilities |
| Selection | eligibility predicate, ranking, threshold, fallback, actual reference keys per request |
| Generator | model tag and actual digest, quantization, full prompts, decoding parameters, seed policy, requests/retries, raw responses |
| Filtering | exact rules, duplicate keys, rejected/accepted counts and reasons, any fallback-generated rows |
| Augmentation | requested and achieved class counts, final synthetic content hash, row provenance |
| Predictor | checkpoint/tokenizer, max tokens, loss/weights, optimizer, epochs, batch size, scheduler, actual steps |
| Execution | software lock, CPU/GPU/device, relevant resource/precision settings, timed regions, interruption/resume record |
| Evaluation | selected metric definition and scale, class order, split, prediction arrays, confusion counts, per-class and aggregate metrics |
| Status | planned/partial/complete/failed, final output paths, explanation for missing cells |

This manifest prevents a CSV from becoming detached from the method that produced it. It also makes a negative result publishable as a reproducible observation rather than an unexplained score.

## 12. Verification performed in this explanatory audit

* Recomputed A3's 36 groups from 180 raw rows and A2's 36 groups from 72 raw rows. Every saved mean/sample SD matched to floating-point tolerance; maximum difference was about 7.1e-15. No duplicate task/ratio/method/seed keys were found.
* Recomputed every B condition's overall summary from its 20 fit rows: six conditions, 120 fits. Four models and five seeds were present in each. Summary errors were below 3e-16.
* Reconstructed B's TP/FN/TN/FP from sensitivity×46 and specificity×697, checked all 120 binary F1 values against those integer counts, and obtained maximum error about 1.1e-16. These are derived counts; saved per-item predictions were not available for an independent prediction-level check.
* Recomputed macro-F1 from 37 saved C seed-replication validation probability arrays with sorted LabelEncoder class order and the corresponding saved validation rows. All 37 matched the JSON exactly. These checks include the newer controlled and confidence-selected completed arms. They do not rerun training.
* Recomputed corrected C paired-seed summaries from the complete saved table. Confirmed five pairs per dataset and recorded the individual paired differences.
* Checked normalized-key duplicates/disjointness for C's saved train/validation/test splits; tabulated all class counts.
* Audited all 90 A synthetic cache files for exact and normalized duplicate excess and fallback markers; summarized 166 local EPIC calls and final-feature distributions.
* Checked that both human-review sheets contain blank judgments.
* Compared mirror/current file inventories and available small text contents. Large weight files with the same size were not declared byte-identical.
* Inspected three A figures and reviewed their generation code to identify aggregation and caption issues.

What was not verified: historical training by rerun; missing A3 provenance; exact installed historical dependency environments; all upstream dataset/raw preprocessing claims; human label correctness; all optional baselines; pretraining contamination; complete unrecorded edit history; or an exhaustive literature/venue search. These limits are explicit so you can tell which claims still need work.

## 13. Reading and writing order

First understand the metric examples in Section 3. Then read the implementation explanation for the project you choose as the paper's core. Reproduce its main table from the supplied CSV evidence. Read its controls and limitations before writing an abstract. Use 03 only when you need the exact function/line, 04 for a change, and 05 for the exact prompt/call. Keep a claim-to-source link beside every result in your draft.

When you write “F1 improved,” state **which F1**, **which evaluation split**, **which comparator**, **how many independent generated sets**, **how many downstream seeds**, **absolute units**, and **what was held fixed**. Those details turn an understandable explanation into an assessable research claim.

