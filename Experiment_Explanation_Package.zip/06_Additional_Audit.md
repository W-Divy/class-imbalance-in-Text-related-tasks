# Additional audit calculations

All calculations read saved artifacts; no models were trained or queried.

## EPIC call totals

{
  "calls": 166,
  "zero_valid_calls": 11,
  "totals": {
    "seconds": 2812.847052300005,
    "valid": 1007.0,
    "candidates": 2195.0,
    "invalid": 1188.0,
    "input_tokens": 476646.0,
    "output_tokens": 168905.0
  },
  "accepted_class_counts": {
    "negative": 562.0,
    "sick": 445.0
  }
}

## EPIC feature profiles

| column | type | real_min | real_median | real_max | synthetic_min | synthetic_median | synthetic_max | synthetic_outside_training_range | real_values | synthetic_values |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| age | numeric | 1.0 | 54.0 | 455.0 | 10.0 | 60.0 | 92.0 | 0.0 |  |  |
| sex | categorical |  |  |  |  |  |  |  | {"F": 1935, "M": 912, "?": 121} | {"F": 869, "M": 127, "?": 4} |
| on_thyroxine | categorical |  |  |  |  |  |  |  | {"f": 2598, "t": 370} | {"f": 945, "t": 55} |
| query_on_thyroxine | categorical |  |  |  |  |  |  |  | {"f": 2930, "t": 38} | {"f": 960, "t": 40} |
| on_antithyroid_medication | categorical |  |  |  |  |  |  |  | {"f": 2934, "t": 34} | {"f": 976, "t": 24} |
| sick | categorical |  |  |  |  |  |  |  | {"f": 2853, "t": 115} | {"f": 981, "t": 19} |
| pregnant | categorical |  |  |  |  |  |  |  | {"f": 2926, "t": 42} | {"f": 999, "t": 1} |
| thyroid_surgery | categorical |  |  |  |  |  |  |  | {"f": 2925, "t": 43} | {"f": 1000} |
| I131_treatment | categorical |  |  |  |  |  |  |  | {"f": 2920, "t": 48} | {"f": 999, "t": 1} |
| query_hypothyroid | categorical |  |  |  |  |  |  |  | {"f": 2784, "t": 184} | {"f": 777, "t": 223} |
| query_hyperthyroid | categorical |  |  |  |  |  |  |  | {"f": 2772, "t": 196} | {"f": 997, "t": 3} |
| lithium | categorical |  |  |  |  |  |  |  | {"f": 2955, "t": 13} | {"f": 997, "t": 3} |
| goitre | categorical |  |  |  |  |  |  |  | {"f": 2939, "t": 29} | {"f": 1000} |
| tumor | categorical |  |  |  |  |  |  |  | {"f": 2888, "t": 80} | {"f": 965, "t": 35} |
| hypopituitary | categorical |  |  |  |  |  |  |  | {"f": 2967, "t": 1} | {"f": 1000} |
| psych | categorical |  |  |  |  |  |  |  | {"f": 2820, "t": 148} | {"f": 914, "t": 86} |
| TSH_measured | categorical |  |  |  |  |  |  |  | {"t": 2710, "f": 258} | {"t": 999, "f": 1} |
| TSH | numeric | 0.005 | 1.6 | 530.0 | 0.001 | 1.14 | 47.0 | 1.0 |  |  |
| T3_measured | categorical |  |  |  |  |  |  |  | {"t": 2387, "f": 581} | {"t": 911, "f": 89} |
| T3 | numeric | 0.05 | 2.013504330446369 | 10.6 | 0.1 | 1.3 | 8.0 | 0.0 |  |  |
| TT4_measured | categorical |  |  |  |  |  |  |  | {"t": 2827, "f": 141} | {"t": 1000} |
| TT4 | numeric | 2.0 | 106.0 | 430.0 | 16.0 | 98.0 | 217.0 | 0.0 |  |  |
| T4U_measured | categorical |  |  |  |  |  |  |  | {"t": 2699, "f": 269} | {"t": 977, "f": 23} |
| T4U | numeric | 0.25 | 0.9949893617021276 | 2.12 | 0.35 | 0.88 | 2.87 | 1.0 |  |  |
| FTI_measured | categorical |  |  |  |  |  |  |  | {"t": 2701, "f": 267} | {"t": 977, "f": 23} |
| FTI | numeric | 2.0 | 110.0 | 395.0 | 14.0 | 108.0 | 218.0 | 0.0 |  |  |
| referral_source | categorical |  |  |  |  |  |  |  | {"other": 1721, "SVI": 819, "SVHC": 306, "STMW": 90, "SVHD": 32} | {"SVI": 591, "other": 405, "SVHD": 2, "SVHC": 1, "STMW": 1} |

## EPIC confusion reconstruction

Sensitivity times 46 and specificity times 697 were rounded to integer counts. All F1 values were checked against 2TP/(2TP+FP+FN). Maximum absolute error: 1.1102230246251565e-16. These are derived counts, not saved prediction vectors.

## Benchmark cache totals

| folder | rows | exact_duplicate_excess | normalized_duplicate_excess | augmented_marker_rows |
| --- | --- | --- | --- | --- |
| v1 | 8264 | 0 | 8 | 0 |
| v2 | 3160 | 0 | 3 | 0 |

## DAIR saved split counts

| label | train | validation | test |
| --- | --- | --- | --- |
| anger | 592 | 126 | 127 |
| fear | 447 | 96 | 96 |
| joy | 1462 | 314 | 313 |
| love | 276 | 59 | 59 |
| sadness | 1312 | 281 | 281 |
| surprise | 111 | 24 | 24 |

## TweetEval saved split counts

| label | train | validation | test |
| --- | --- | --- | --- |
| anger | 1400 | 160 | 558 |
| joy | 683 | 97 | 358 |
| optimism | 294 | 28 | 123 |
| sadness | 855 | 89 | 382 |

## TREC saved split counts

| label | train | validation | test |
| --- | --- | --- | --- |
| ABBR | 71 | 13 | 9 |
| DESC | 974 | 172 | 138 |
| ENTY | 1058 | 187 | 94 |
| HUM | 1033 | 182 | 65 |
| LOC | 699 | 124 | 81 |
| NUM | 728 | 128 | 113 |

## Review sheet: E:\CodexProjects\thew-x20\outputs\synthetic_label_review_sheet.csv

| column | nonempty | rows |
| --- | --- | --- |
| item_id | 260 | 260 |
| dataset | 260 | 260 |
| text | 260 | 260 |
| label | 260 | 260 |
| label_correct_0_or_1 | 0 | 260 |
| natural_for_dataset_0_or_1 | 0 | 260 |
| notes | 0 | 260 |

## Review sheet: E:\CodexProjects\thew-x20\outputs\controlled_generation_v2\trec6\generation_seed101\blinded_label_review.csv

| column | nonempty | rows |
| --- | --- | --- |
| item_id | 225 | 225 |
| text | 225 | 225 |
| proposed_label | 225 | 225 |
| reviewer_label | 0 | 225 |
| naturalness_1_to_5 | 0 | 225 |
| notes | 0 | 225 |
