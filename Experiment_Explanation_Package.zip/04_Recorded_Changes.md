# Recorded changes and mirror comparison

A snapshot comparison does not recover edits that were overwritten without a backup. The mirror is a comparison snapshot; it is not assumed to be an authoritative revision history.

## work\audit_reference_correctness.py

```diff
--- mirror/work\audit_reference_correctness.py
+++ current/work\audit_reference_correctness.py
@@ -2,10 +2,10 @@
 import json
 import pandas as pd
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 cases = [
     ('dair_emotion',
-     Path(r'C:/Users/Lenovo/Downloads/bert_results/merged_training/anchor_probabilities_and_margins.csv'),
+     Path(r'E:/CodexProjects/thew-x20/external/merged_training/anchor_probabilities_and_margins.csv'),
      root / 'outputs/controlled_experiments_same_pool/random_reference_prompts.jsonl'),
     ('tweet_eval_emotion',
      root / 'outputs/tweet_eval_emotion/scored_training_anchors.csv',

```

## work\build_llm_comparison.py

```diff
--- mirror/work\build_llm_comparison.py
+++ current/work\build_llm_comparison.py
@@ -1,7 +1,7 @@
 from pathlib import Path
 import nbformat as nbf
 
-original = nbf.read('C:/Users/Lenovo/Downloads/DL_class_imbalance_BERT.ipynb', as_version=4)
+original = nbf.read('E:/CodexProjects/thew-x20/external/DL_class_imbalance_BERT.ipynb', as_version=4)
 cells = []
 def md(s): cells.append(nbf.v4.new_markdown_cell(s.strip()))
 def code(s): cells.append(nbf.v4.new_code_cell(s.strip()))
@@ -14,7 +14,7 @@
 
 The strict margin threshold produced no anchors for surprise. We retain strict anchors where possible and supplement sparse classes with their lowest positive-margin examples. This fallback is logged and is not described as a true near-boundary example. Generated labels are unreviewed; results are exploratory. The already-viewed test set is not reevaluated or used for choosing settings.''')
 reuse(3); reuse(4); reuse(5)
-code('''SOURCE_DIR = Path(r"C:/Users/Lenovo/Downloads/bert_results/merged_training")
+code('''SOURCE_DIR = Path(r"E:/CodexProjects/thew-x20/external/merged_training")
 RUN_DIR = Path.cwd() / "llm_comparison_run"
 RUN_DIR.mkdir(parents=True, exist_ok=True)
 settings = json.loads((SOURCE_DIR / "settings.json").read_text())

```

## work\build_notebook.py

```diff
--- mirror/work\build_notebook.py
+++ current/work\build_notebook.py
@@ -49,7 +49,7 @@
 from tqdm.auto import tqdm''')
 md('''## 2. Settings — change the dataset here
 For another file with the same columns, only change `DATA_PATH`. If its schema differs, also change `TEXT_COLUMN` and `LABEL_COLUMN`. `DATASET_NAME` is a display name, not a download command. BERT below is English; use a suitable BERT checkpoint for another language. Output files are saved in a dataset-specific run folder; use a new folder for a new experiment.''')
-code('''DATA_PATH = Path(r"C:/Users/Lenovo/Downloads/archive (8)/merged_training.pkl")
+code('''DATA_PATH = Path(r"E:/CodexProjects/thew-x20/external/merged_training.pkl")
 DATASET_NAME = DATA_PATH.stem
 TEXT_COLUMN = "text"
 LABEL_COLUMN = "emotions"

```

## work\build_reusable_notebook.py

```diff
--- mirror/work\build_reusable_notebook.py
+++ current/work\build_reusable_notebook.py
@@ -2,7 +2,7 @@
 from pathlib import Path
 import nbformat as nbf
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 out = root / 'outputs/reusable_imbalance_bert_llm.ipynb'
 nb = nbf.v4.new_notebook()
 cells = []
@@ -35,7 +35,7 @@
 from transformers import AutoTokenizer, AutoModelForSequenceClassification, set_seed''')
 
 md('## 1. Dataset and experiment settings')
-code('''DATASET_DIR = Path(r"C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20/work/trec6")
+code('''DATASET_DIR = Path(r"E:/CodexProjects/thew-x20/work/trec6")
 RUN_DIR = Path.cwd() / "imbalance_runs" / DATASET_DIR.name
 RUN_DIR.mkdir(parents=True, exist_ok=True)
 SEED = 42

```

## work\finalize_llm.py

```diff
--- mirror/work\finalize_llm.py
+++ current/work\finalize_llm.py
@@ -11,7 +11,7 @@
 nb = nbformat.read(nb_path, as_version=4)
 assert all(c.execution_count is not None for c in nb.cells if c.cell_type == 'code')
 assert not any(o.output_type == 'error' for c in nb.cells if c.cell_type == 'code' for o in c.outputs)
-source = nbformat.read('C:/Users/Lenovo/Downloads/DL_class_imbalance_BERT.ipynb', as_version=4)
+source = nbformat.read('E:/CodexProjects/thew-x20/external/DL_class_imbalance_BERT.ipynb', as_version=4)
 nb.metadata['kernelspec'] = source.metadata['kernelspec']
 nbformat.validate(nb)
 nbformat.write(nb, nb_path)

```

## work\make_label_audit_sheet.py

```diff
--- mirror/work\make_label_audit_sheet.py
+++ current/work\make_label_audit_sheet.py
@@ -1,7 +1,7 @@
 from pathlib import Path
 import pandas as pd
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 sources = [
     ('dair_emotion', 'margin', root / 'outputs/llm_comparison_run/synthetic_used_unreviewed.csv'),
     ('dair_emotion', 'random_correct_pool', root / 'outputs/controlled_experiments_correct_pool/random_reference_synthetic.csv'),

```

## work\paired_bootstrap.py

```diff
--- mirror/work\paired_bootstrap.py
+++ current/work\paired_bootstrap.py
@@ -6,7 +6,7 @@
 import pandas as pd
 from sklearn.metrics import f1_score
 
-base = Path(r'C:/Users/Lenovo/Downloads/bert_results/merged_training')
+base = Path(r'E:/CodexProjects/thew-x20/external/merged_training')
 root = Path('outputs')
 val = pd.read_csv(base / 'validation_split.csv')
 y = val.label_id.to_numpy()

```

## work\plot_anchor_availability.py

```diff
--- mirror/work\plot_anchor_availability.py
+++ current/work\plot_anchor_availability.py
@@ -2,7 +2,7 @@
 import pandas as pd
 import matplotlib.pyplot as plt
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 sources = {
     'DAIR': root / 'outputs/llm_comparison_run/selected_anchors.csv',
     'TweetEval': root / 'outputs/tweet_eval_emotion/selected_anchors.csv',

```

## work\plot_seed_differences.py

```diff
--- mirror/work\plot_seed_differences.py
+++ current/work\plot_seed_differences.py
@@ -2,7 +2,7 @@
 import pandas as pd
 import matplotlib.pyplot as plt
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 frame = pd.read_csv(root / 'outputs/seed_replications/paired_seed_differences.csv')
 fig, ax = plt.subplots(figsize=(8, 4.5))
 colors = {'dair_emotion': '#4c78a8', 'tweet_eval_emotion': '#e45756'}

```

## work\plot_trec_distribution.py

```diff
--- mirror/work\plot_trec_distribution.py
+++ current/work\plot_trec_distribution.py
@@ -2,7 +2,7 @@
 import pandas as pd
 import matplotlib.pyplot as plt
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 folder = root / 'work/trec6'
 train = pd.read_csv(folder / 'train.csv')
 val = pd.read_csv(folder / 'validation.csv')

```

## work\plot_tweet_style.py

```diff
--- mirror/work\plot_tweet_style.py
+++ current/work\plot_tweet_style.py
@@ -2,7 +2,7 @@
 import pandas as pd
 import matplotlib.pyplot as plt
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 df = pd.read_csv(root / 'outputs/tweet_style_audit.csv')
 classes = ['joy', 'optimism', 'sadness']
 groups = ['train', 'validation', 'margin_llm', 'random_llm', 'random_correct_llm']

```

## work\prepare_trec6.py

```diff
--- mirror/work\prepare_trec6.py
+++ current/work\prepare_trec6.py
@@ -7,7 +7,7 @@
 import pandas as pd
 from sklearn.model_selection import train_test_split
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 dest = root / 'work/trec6'
 dest.mkdir(parents=True, exist_ok=True)
 base = 'https://cogcomp.seas.upenn.edu/Data/QA/QC/'

```

## work\quality_audit.py

```diff
--- mirror/work\quality_audit.py
+++ current/work\quality_audit.py
@@ -10,8 +10,8 @@
 root = Path('outputs')
 specs = [
     ('DAIR Emotion',
-     Path(r'C:/Users/Lenovo/Downloads/bert_results/merged_training/train_split.csv'),
-     Path(r'C:/Users/Lenovo/Downloads/bert_results/merged_training/validation_split.csv'),
+     Path(r'E:/CodexProjects/thew-x20/external/merged_training/train_split.csv'),
+     Path(r'E:/CodexProjects/thew-x20/external/merged_training/validation_split.csv'),
      root / 'llm_comparison_run/synthetic_used_unreviewed.csv',
      root / 'controlled_experiments_same_pool/random_reference_synthetic.csv'),
     ('TweetEval emotion',

```

## work\run_controls.py

```diff
--- mirror/work\run_controls.py
+++ current/work\run_controls.py
@@ -16,13 +16,13 @@
 from torch.utils.data import Dataset, DataLoader
 from tqdm.auto import tqdm
 
-BASE = Path(r"C:/Users/Lenovo/Downloads/bert_results/merged_training")
-PRIOR = Path(r"C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20/outputs/llm_comparison_run")
+BASE = Path(r"E:/CodexProjects/thew-x20/external/merged_training")
+PRIOR = Path(r"E:/CodexProjects/thew-x20/outputs/llm_comparison_run")
 CORRECT_POOL = os.environ.get("CODEX_CORRECT_POOL_CONTROL") == "1"
 SAME_POOL = os.environ.get("CODEX_SAME_POOL_CONTROL") == "1" or CORRECT_POOL
 folder = ("controlled_experiments_correct_pool" if CORRECT_POOL else
           "controlled_experiments_same_pool" if SAME_POOL else "controlled_experiments")
-OUT = Path(r"C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20/outputs") / folder
+OUT = Path(r"E:/CodexProjects/thew-x20/outputs") / folder
 OUT.mkdir(parents=True, exist_ok=True)
 settings = json.loads((BASE / "settings.json").read_text(encoding="utf-8"))
 SEED = settings["SEED"]

```

## work\run_seed_replications.py

```diff
--- mirror/work\run_seed_replications.py
+++ current/work\run_seed_replications.py
@@ -15,13 +15,17 @@
 import time
 import subprocess
 
-ROOT = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+ROOT = Path(r'E:/CodexProjects/thew-x20')
 OUT = ROOT / 'outputs/seed_replications'
 OUT.mkdir(parents=True, exist_ok=True)
-SOURCE = nbformat.read(r'C:/Users/Lenovo/Downloads/DL_class_imbalance_BERT.ipynb', as_version=4)
-MODEL_NAME, MAX_LENGTH, BATCH_SIZE, EPOCHS = 'bert-base-uncased', 128, 16, 3
+SOURCE = nbformat.read(r'E:/CodexProjects/thew-x20/external/DL_class_imbalance_BERT.ipynb', as_version=4)
+MODEL_NAME, MAX_LENGTH, BATCH_SIZE, EPOCHS = (
+    'bert-base-uncased', int(os.environ.get('IMBALANCE_MAX_LENGTH', '128')), 16, 3)
 LEARNING_RATE, FOCAL_GAMMA = 2e-5, 2.0
-device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
+device = torch.device('cpu' if os.environ.get('IMBALANCE_FORCE_CPU') == '1'
+                      else ('cuda' if torch.cuda.is_available() else 'cpu'))
+if device.type == 'cpu':
+    torch.set_num_threads(int(os.environ.get('IMBALANCE_CPU_THREADS', '4')))
 if device.type == 'cuda':
     # Leave headroom for Windows and the display driver on a 6 GB laptop GPU.
     torch.cuda.set_per_process_memory_fraction(0.75)
@@ -30,7 +34,10 @@
 ONLY_DATASET = os.environ.get('IMBALANCE_ONLY_DATASET')
 ONLY_METHOD = os.environ.get('IMBALANCE_ONLY_METHOD')
 ONLY_SEED = os.environ.get('IMBALANCE_ONLY_SEED')
+EXTRA_SYNTHETIC = os.environ.get('IMBALANCE_EXTRA_SYNTHETIC')
+EXTRA_METHOD = os.environ.get('IMBALANCE_EXTRA_METHOD')
 STEP_PAUSE_SECONDS = float(os.environ.get('IMBALANCE_STEP_PAUSE', '0.15'))
+THERMAL_CHECK_EVERY = int(os.environ.get('IMBALANCE_THERMAL_CHECK_EVERY', '10'))
 PAUSE_AT_C = int(os.environ.get('IMBALANCE_PAUSE_AT_C', '79'))
 RESUME_AT_C = int(os.environ.get('IMBALANCE_RESUME_AT_C', '70'))
 
@@ -43,7 +50,7 @@
     )
     return int(output.strip().splitlines()[0])
 
-def train_bert_thermally_limited(frame, loss_kind='ordinary'):
+def train_bert_thermally_limited(frame, loss_kind='ordinary', checkpoint_path=None):
     """Train one model while yielding GPU time and pausing before heat accumulates."""
     model = new_bert()
     loader = make_loader(frame, shuffle=True)
@@ -54,8 +61,20 @@
     weights = torch.tensor(len(frame) / (NUM_CLASSES * counts),
                            dtype=torch.float32, device=device)
     history = []
+    first_epoch = 0
+    if checkpoint_path is not None and checkpoint_path.exists():
+        saved = torch.load(checkpoint_path, map_location=device, weights_only=False)
+        model.load_state_dict(saved['model'])
+        optimizer.load_state_dict(saved['optimizer'])
+        history = saved['history']
+        first_epoch = saved['next_epoch']
+        torch.set_rng_state(saved['torch_rng'])
+        loader.generator.set_state(saved['loader_rng'])
+        if device.type == 'cuda' and 'cuda_rng' in saved:
+            torch.cuda.set_rng_state(saved['cuda_rng'])
+        print(f'Resuming at epoch {first_epoch + 1}/{EPOCHS}', flush=True)
     start = time.perf_counter()
-    for epoch in range(EPOCHS):
+    for epoch in range(first_epoch, EPOCHS):
         model.train()
         losses = []
         for batch_index, batch in enumerate(loader):
@@ -69,7 +88,7 @@
             optimizer.step()
             losses.append(loss.item())
             time.sleep(STEP_PAUSE_SECONDS)
-            if device.type == 'cuda' and (batch_index + 1) % 20 == 0:
+            if device.type == 'cuda' and (batch_index + 1) % THERMAL_CHECK_EVERY == 0:
                 temperature = gpu_temperature()
                 if temperature >= PAUSE_AT_C:
                     print(f'GPU {temperature}C: cooling to {RESUME_AT_C}C', flush=True)
@@ -77,13 +96,23 @@
                         time.sleep(5)
         history.append(float(np.mean(losses)))
         print(f'Mean batch loss: {history[-1]:.4f}', flush=True)
+        if checkpoint_path is not None and epoch + 1 < EPOCHS:
+            saved = {
+                'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
+                'history': history, 'next_epoch': epoch + 1,
+                'torch_rng': torch.get_rng_state(),
+                'loader_rng': loader.generator.get_state(),
+            }
+            if device.type == 'cuda':
+                saved['cuda_rng'] = torch.cuda.get_rng_state()
+            torch.save(saved, checkpoint_path)
     return model, history, time.perf_counter() - start, len(loader) * EPOCHS
 
 datasets = [
     {
         'name': 'dair_emotion',
-        'train': Path(r'C:/Users/Lenovo/Downloads/bert_results/merged_training/train_split.csv'),
-        'validation': Path(r'C:/Users/Lenovo/Downloads/bert_results/merged_training/validation_split.csv'),
+        'train': Path(r'E:/CodexProjects/thew-x20/external/merged_training/train_split.csv'),
+        'validation': Path(r'E:/CodexProjects/thew-x20/external/merged_training/validation_split.csv'),
         'methods': {
             'margin_llm': ROOT / 'outputs/llm_comparison_run/synthetic_used_unreviewed.csv',
             'random_llm_same_pool': ROOT / 'outputs/controlled_experiments_same_pool/random_reference_synthetic.csv',
@@ -105,6 +134,8 @@
         'train': ROOT / 'work/trec6/train.csv',
         'validation': ROOT / 'work/trec6/validation.csv',
         'methods': {
+            'baseline': None,
+            'class_weights': None,
             'margin_llm': ROOT / 'outputs/trec6/margin_synthetic.csv',
             'random_correct_pool_llm': ROOT / 'outputs/trec6/random_correct_pool_synthetic.csv',
         }
@@ -114,6 +145,10 @@
 for spec in datasets:
     if ONLY_DATASET and spec['name'] != ONLY_DATASET:
         continue
+    if EXTRA_SYNTHETIC:
+        if not EXTRA_METHOD or not ONLY_DATASET:
+            raise ValueError('Extra synthetic data requires method and dataset selectors')
+        spec['methods'] = {EXTRA_METHOD: Path(EXTRA_SYNTHETIC)}
     ds_out = OUT / spec['name']
     ds_out.mkdir(exist_ok=True)
     train_df = pd.read_csv(spec['train'], dtype={'label': str})
@@ -131,12 +166,17 @@
     for name, path in spec['methods'].items():
         if ONLY_METHOD and name != ONLY_METHOD:
             continue
-        synthetic = pd.read_csv(path, dtype={'label': str})
-        synthetic['label_id'] = encoder.transform(synthetic.label)
-        assert not synthetic.key.duplicated().any()
-        assert set(synthetic.key).isdisjoint(set(train_df.key) | set(val_df.key))
-        frame = pd.concat([train_df, synthetic], ignore_index=True)
-        for seed in (43, 44, 45, 46):
+        if path is None:
+            synthetic = pd.DataFrame(columns=train_df.columns)
+            frame = train_df.copy()
+        else:
+            synthetic = pd.read_csv(path, dtype={'label': str})
+            synthetic['label_id'] = encoder.transform(synthetic.label)
+            assert not synthetic.key.duplicated().any()
+            assert set(synthetic.key).isdisjoint(set(train_df.key) | set(val_df.key))
+            frame = pd.concat([train_df, synthetic], ignore_index=True)
+        seeds = (int(ONLY_SEED),) if ONLY_SEED else (43, 44, 45, 46)
+        for seed in seeds:
             if ONLY_SEED and seed != int(ONLY_SEED):
                 continue
             result_path = ds_out / f'{name}_seed{seed}.json'
@@ -144,7 +184,10 @@
                 print('Already completed', result_path, flush=True)
                 continue
             SEED = seed
-            model, history, seconds, steps = train_bert(frame)
+            loss_kind = 'weighted' if name == 'class_weights' else 'ordinary'
+            checkpoint_path = ds_out / f'{name}_seed{seed}_checkpoint.pt'
+            model, history, seconds, steps = train_bert(
+                frame, loss_kind=loss_kind, checkpoint_path=checkpoint_path)
             probabilities = predict_probabilities(model, val_df)
             prediction = probabilities.argmax(1)
             truth = val_df.label_id.to_numpy()
@@ -159,10 +202,12 @@
                 'accuracy': float(accuracy_score(truth, prediction)),
                 'per_class_f1': dict(zip(class_names, map(float, class_scores))),
                 'train_minutes': seconds / 60, 'optimizer_steps': steps,
+                'max_length': MAX_LENGTH, 'device': device.type,
                 'training_losses': history
             }
             np.save(ds_out / f'{name}_seed{seed}_validation_probabilities.npy', probabilities)
             result_path.write_text(json.dumps(result, indent=2), encoding='utf-8')
+            checkpoint_path.unlink(missing_ok=True)
             print(f"{spec['name']} {name} seed {seed}: macro-F1 {result['macro_f1']:.4f}", flush=True)
             del model
             release_memory()

```

## work\run_trec6_margin.py

```diff
--- mirror/work\run_trec6_margin.py
+++ current/work\run_trec6_margin.py
@@ -19,11 +19,11 @@
 from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
 import nbformat
 
-ROOT = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+ROOT = Path(r'E:/CodexProjects/thew-x20')
 DATA = ROOT / 'work/trec6'
 OUT = ROOT / 'outputs/trec6'
 OUT.mkdir(parents=True, exist_ok=True)
-SOURCE = nbformat.read(r'C:/Users/Lenovo/Downloads/DL_class_imbalance_BERT.ipynb', as_version=4)
+SOURCE = nbformat.read(r'E:/CodexProjects/thew-x20/external/DL_class_imbalance_BERT.ipynb', as_version=4)
 SEED, MODEL_NAME, MAX_LENGTH, BATCH_SIZE, EPOCHS = 42, 'bert-base-uncased', 128, 16, 3
 LEARNING_RATE, FOCAL_GAMMA = 2e-5, 2.0
 OLLAMA_BASE, LLM_MODEL = 'http://127.0.0.1:11434', 'qwen2.5:3b'

```

## work\run_tweeteval_augmentation.py

```diff
--- mirror/work\run_tweeteval_augmentation.py
+++ current/work\run_tweeteval_augmentation.py
@@ -17,12 +17,12 @@
 from sklearn.metrics import f1_score, balanced_accuracy_score, accuracy_score
 import nbformat
 
-ROOT = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+ROOT = Path(r'E:/CodexProjects/thew-x20')
 DATA = ROOT / 'work/tweet_eval_emotion'
 OUT = ROOT / 'outputs/tweet_eval_emotion'
 OUT.mkdir(parents=True, exist_ok=True)
 CORRECT_POOL = os.environ.get('CODEX_CORRECT_POOL_CONTROL') == '1'
-SOURCE_NB = nbformat.read(r'C:/Users/Lenovo/Downloads/DL_class_imbalance_BERT.ipynb', as_version=4)
+SOURCE_NB = nbformat.read(r'E:/CodexProjects/thew-x20/external/DL_class_imbalance_BERT.ipynb', as_version=4)
 SEED, MODEL_NAME, MAX_LENGTH, BATCH_SIZE, EPOCHS = 42, 'bert-base-uncased', 128, 16, 3
 LEARNING_RATE, FOCAL_GAMMA = 2e-5, 2.0
 OLLAMA_BASE, LLM_MODEL = 'http://127.0.0.1:11434', 'qwen2.5:3b'

```

## work\run_tweeteval_baselines.py

```diff
--- mirror/work\run_tweeteval_baselines.py
+++ current/work\run_tweeteval_baselines.py
@@ -14,11 +14,11 @@
 from sklearn.metrics import f1_score, balanced_accuracy_score, accuracy_score
 import nbformat
 
-ROOT = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+ROOT = Path(r'E:/CodexProjects/thew-x20')
 DATA = ROOT / 'work/tweet_eval_emotion'
 OUT = ROOT / 'outputs/tweet_eval_emotion'
 OUT.mkdir(parents=True, exist_ok=True)
-SOURCE_NB = nbformat.read(r'C:/Users/Lenovo/Downloads/DL_class_imbalance_BERT.ipynb', as_version=4)
+SOURCE_NB = nbformat.read(r'E:/CodexProjects/thew-x20/external/DL_class_imbalance_BERT.ipynb', as_version=4)
 SEED = 42
 MODEL_NAME = 'bert-base-uncased'
 MAX_LENGTH = 128

```

## work\summarize_correct_pool.py

```diff
--- mirror/work\summarize_correct_pool.py
+++ current/work\summarize_correct_pool.py
@@ -3,7 +3,7 @@
 import json
 import pandas as pd
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 folder = root / 'outputs/seed_replications'
 rows = []
 

```

## work\summarize_training_seeds.py

```diff
--- mirror/work\summarize_training_seeds.py
+++ current/work\summarize_training_seeds.py
@@ -2,7 +2,7 @@
 import json
 import pandas as pd
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 out = root / 'outputs/seed_replications'
 rows = []
 for path in out.glob('*/*.json'):

```

## work\trec_conditional_bootstrap.py

```diff
--- mirror/work\trec_conditional_bootstrap.py
+++ current/work\trec_conditional_bootstrap.py
@@ -6,7 +6,7 @@
 from sklearn.metrics import f1_score
 from sklearn.preprocessing import LabelEncoder
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 val = pd.read_csv(root / 'work/trec6/validation.csv')
 train = pd.read_csv(root / 'work/trec6/train.csv')
 encoder = LabelEncoder().fit(train.label)

```

## work\trec_quality_audit.py

```diff
--- mirror/work\trec_quality_audit.py
+++ current/work\trec_quality_audit.py
@@ -2,7 +2,7 @@
 import pandas as pd
 from sklearn.feature_extraction.text import TfidfVectorizer
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 train = pd.read_csv(root / 'work/trec6/train.csv')
 validation = pd.read_csv(root / 'work/trec6/validation.csv')
 folder = root / 'outputs/trec6'

```

## work\tweet_style_audit.py

```diff
--- mirror/work\tweet_style_audit.py
+++ current/work\tweet_style_audit.py
@@ -3,7 +3,7 @@
 import re
 import pandas as pd
 
-root = Path(r'C:/Users/Lenovo/Documents/Codex/2026-10-08/thew-x20')
+root = Path(r'E:/CodexProjects/thew-x20')
 paths = {
     'train': root / 'work/tweet_eval_emotion/train.csv',
     'validation': root / 'work/tweet_eval_emotion/validation.csv',

```

## EPIC launcher before and after Python fix

```diff
--- D:\EPIC_free_reproduction\epic-free\run_core.ps1.before-python-fix
+++ D:\EPIC_free_reproduction\epic-free\run_core.ps1
@@ -1,15 +1,36 @@
 param(
     [string]$Model = 'qwen2.5:3b',
-    [string]$RunName = 'local-epic'
+    [string]$RunName = 'local-epic',
+    [string]$PythonExe = '',
+    [switch]$CheckOnly
 )
 $ErrorActionPreference = 'Stop'
 Set-Location $PSScriptRoot
+# A new PowerShell profile can reset PATH to base Anaconda. Resolve once,
+# then invoke the absolute interpreter path for every pipeline stage.
+if (-not $PythonExe) {
+    $epicPython = Join-Path $env:USERPROFILE 'anaconda3\envs\epic-free\python.exe'
+    if (Test-Path -LiteralPath $epicPython) {
+        $PythonExe = $epicPython
+    } elseif ($env:CONDA_PREFIX -and $env:CONDA_DEFAULT_ENV -eq 'epic-free') {
+        $PythonExe = Join-Path $env:CONDA_PREFIX 'python.exe'
+    } else {
+        throw 'Pass -PythonExe with the full path to your epic-free python.exe.'
+    }
+}
+if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {
+    throw "Python interpreter not found: $PythonExe"
+}
+$PythonExe = (Resolve-Path -LiteralPath $PythonExe).Path
+Write-Host "Using Python: $PythonExe"
 function Run-Python {
-    & python @args
+    & $PythonExe @args
     if ($LASTEXITCODE -ne 0) { throw "Python command failed: $args" }
 }
+Run-Python -c "import sys, numpy, pandas, scipy, sklearn, imblearn, xgboost, catboost, lightgbm, matplotlib, requests; print('Dependency check passed:', sys.executable)"
 Run-Python epic.py audit
 Run-Python -m unittest -v test_core.py
+if ($CheckOnly) { return }
 if (-not (Test-Path classifier_params.json)) {
     Run-Python epic.py tune --out classifier_params.json
 }

```
